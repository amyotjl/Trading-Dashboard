// Mock SEDI transaction data — Canadian insider filings
// Structure mirrors the real Rails API response shape

const ISSUERS = [
  { ticker: "ENB.TO", name: "Enbridge Inc.", sector: "Energy", home_page: "enbridge.com", description: "Multinational pipeline and energy company headquartered in Calgary, Alberta. Operates the longest crude oil transportation system in the world.", price: 56.42 },
  { ticker: "SU.TO", name: "Suncor Energy Inc.", sector: "Energy", home_page: "suncor.com", description: "Integrated energy company based in Calgary. Specializes in oil sands development and synthetic crude production.", price: 49.18 },
  { ticker: "TD.TO", name: "Toronto-Dominion Bank", sector: "Financial Services", home_page: "td.com", description: "One of Canada's two largest banks. Provides retail, commercial, and wholesale banking services across North America.", price: 82.07 },
  { ticker: "RY.TO", name: "Royal Bank of Canada", sector: "Financial Services", home_page: "rbc.com", description: "Largest Canadian bank by market capitalization. Operates in personal and commercial banking, wealth management, and capital markets.", price: 168.43 },
  { ticker: "BNS.TO", name: "Bank of Nova Scotia", sector: "Financial Services", home_page: "scotiabank.com", description: "Third-largest Canadian bank with significant operations in Latin America and the Caribbean.", price: 71.20 },
  { ticker: "CNR.TO", name: "Canadian National Railway", sector: "Industrials", home_page: "cn.ca", description: "Class I freight railway operating across Canada and the central United States. Largest railway in Canada by revenue.", price: 152.88 },
  { ticker: "BCE.TO", name: "BCE Inc.", sector: "Communication Services", home_page: "bce.ca", description: "Largest telecommunications company in Canada. Owns Bell Canada and Bell Media.", price: 33.94 },
  { ticker: "SHOP.TO", name: "Shopify Inc.", sector: "Technology", home_page: "shopify.com", description: "Multinational e-commerce platform headquartered in Ottawa. Provides commerce infrastructure for merchants worldwide.", price: 142.61 },
  { ticker: "CP.TO", name: "Canadian Pacific Kansas City", sector: "Industrials", home_page: "cpkcr.com", description: "Transcontinental freight railway formed by the 2023 merger of Canadian Pacific and Kansas City Southern.", price: 108.55 },
  { ticker: "MFC.TO", name: "Manulife Financial Corp.", sector: "Financial Services", home_page: "manulife.com", description: "Multinational insurance and financial services provider. Largest insurance company in Canada.", price: 44.83 },
  { ticker: "CNQ.TO", name: "Canadian Natural Resources", sector: "Energy", home_page: "cnrl.com", description: "Senior independent crude oil and natural gas producer. Operations span Western Canada, the North Sea, and offshore Africa.", price: 47.92 },
  { ticker: "IGM.TO", name: "IGM Financial Inc.", sector: "Financial Services", home_page: "igmfinancial.com", description: "Holding company providing wealth and asset management services. Subsidiary of Power Corporation of Canada.", price: 41.05 },
  { ticker: "WCN.TO", name: "Waste Connections Inc.", sector: "Industrials", home_page: "wasteconnections.com", description: "Integrated solid waste services company. Third-largest waste handler in North America.", price: 248.30 },
  { ticker: "ABX.TO", name: "Barrick Gold Corp.", sector: "Basic Materials", home_page: "barrick.com", description: "World's second-largest gold mining company. Operations across North America, South America, Africa, and the Middle East.", price: 22.14 },
];

const INSIDER_NAMES = [
  "MacDonald, Catherine A.",
  "Tremblay, Jean-Philippe",
  "Singh, Rajinder",
  "O'Brien, Patrick M.",
  "Chen, Wei-Lin",
  "Beaulieu, Sophie",
  "Kowalski, Marcin",
  "Patel, Anjali",
  "Forbes, Douglas R.",
  "Lévesque, Marie-Claude",
  "Anderson, Heather L.",
  "Nakamura, Kenji",
  "Wright, Geoffrey T.",
  "Dubois, Antoine",
  "Reyes, Isabella M.",
  "McLeod, Fiona J.",
  "Hassan, Omar",
  "Pelletier, Étienne",
  "Bhattacharya, Priya",
  "Lindgren, Erik S.",
];

const RELATIONSHIPS = [
  { code: "1", description: "Issuer" },
  { code: "2", description: "Subsidiary of Issuer" },
  { code: "3", description: "10% Security Holder of Issuer" },
  { code: "4", description: "Director of Issuer" },
  { code: "5", description: "Senior Officer of Issuer" },
  { code: "6", description: "Director or Senior Officer of 10% Security Holder" },
  { code: "7", description: "Director or Senior Officer of Insider or Subsidiary of Issuer" },
  { code: "8", description: "Deemed Insider — 6 Months before becoming Insider" },
];

const NATURE_OF_TXN = [
  { code: "00", description: "Opening Balance-Initial SEDI Report" },
  { code: "10", description: "Acquisition in the public market" },
  { code: "11", description: "Acquisition or disposition in the public market" },
  { code: "22", description: "Acquisition under a purchase/ownership plan" },
  { code: "30", description: "Acquisition or disposition by gift" },
  { code: "38", description: "Redemption, retraction, cancellation, repurchase" },
  { code: "47", description: "Acquisition or disposition pursuant to a prospectus exempt distribution" },
  { code: "51", description: "Exercise of options" },
  { code: "54", description: "Grant of options" },
  { code: "57", description: "Exercise of warrants" },
  { code: "70", description: "Acquisition or disposition under a stock split" },
  { code: "97", description: "Other" },
];

const SECURITY_DESIGNATIONS = [
  "Common Shares",
  "Restricted Share Units",
  "Performance Share Units",
  "Deferred Share Units",
  "Stock Options",
  "Class A Subordinate Voting Shares",
];

const OWNERSHIP_TYPES = [
  { category: "Direct", entity_name: null },
  { category: "Indirect", entity_name: "Beedie Investments Limited" },
  { category: "Indirect", entity_name: "RRSP" },
  { category: "Indirect", entity_name: "Spouse" },
  { category: "Indirect", entity_name: "Family Trust" },
];

// Deterministic pseudo-random so the dataset is stable across reloads
function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(20250323);
const pick = (arr) => arr[Math.floor(rng() * arr.length)];
const between = (a, b) => a + rng() * (b - a);

function generateTransactions(n = 420) {
  const rows = [];
  const startDate = new Date(2025, 0, 2);
  for (let i = 0; i < n; i++) {
    const issuer = pick(ISSUERS);
    const insider = pick(INSIDER_NAMES);
    const nature = pick(NATURE_OF_TXN);
    const security = pick(SECURITY_DESIGNATIONS);
    const ownership = pick(OWNERSHIP_TYPES);
    const rels = [pick(RELATIONSHIPS)];
    if (rng() > 0.65) rels.push(pick(RELATIONSHIPS));

    const isAcq = ["10", "11", "22", "51", "54", "57", "70"].includes(nature.code) && rng() > 0.35;
    const sign = isAcq ? 1 : -1;
    const shares = sign * Math.floor(between(100, 25000));
    const priceJitter = between(-0.04, 0.04);
    const price = Math.max(0.5, issuer.price * (1 + priceJitter));

    const dayOffset = Math.floor(rng() * 80);
    const txnDate = new Date(startDate.getTime() + dayOffset * 86400000);
    const filingDate = new Date(txnDate.getTime() + (1 + Math.floor(rng() * 4)) * 86400000);

    rows.push({
      id: i + 1,
      sedi_transaction_id: 8000000 + i,
      transaction_date: txnDate.toISOString().slice(0, 10),
      filing_date: filingDate.toISOString().slice(0, 10),
      number_of_securities: shares,
      unit_price: nature.code === "54" ? null : Math.round(price * 100) / 100,
      balance: Math.floor(between(5000, 500000)),
      insider_name: insider,
      issuer_ticker: issuer.ticker,
      issuer_name: issuer.name,
      relationships: rels.map((r) => r.description),
      security_designation: security,
      ownership_type: ownership,
      nature_of_transaction: nature,
    });
  }
  // Sort by filing_date desc by default
  rows.sort((a, b) => b.filing_date.localeCompare(a.filing_date));
  return rows;
}

const TRANSACTIONS = generateTransactions(420);

// Generate 2y of OHLCV per issuer (daily)
function generateOHLCV(basePrice, days = 504) {
  const out = [];
  let close = basePrice * 0.78; // start lower so chart trends upward overall
  const today = new Date(2025, 2, 28); // March 28, 2025 = "today" in the mock
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 86400000);
    if (d.getDay() === 0 || d.getDay() === 6) continue; // skip weekends
    const drift = (basePrice - close) * 0.005;
    const noise = (rng() - 0.5) * close * 0.025;
    const open = close;
    close = Math.max(0.5, open + drift + noise);
    const high = Math.max(open, close) + rng() * close * 0.012;
    const low = Math.min(open, close) - rng() * close * 0.012;
    const volume = Math.floor(between(0.5e6, 8e6));
    out.push({
      date: d.toISOString().slice(0, 10),
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +low.toFixed(2),
      close: +close.toFixed(2),
      volume,
    });
  }
  return out;
}

const OHLCV_CACHE = {};
function getOHLCV(ticker) {
  if (!OHLCV_CACHE[ticker]) {
    const issuer = ISSUERS.find((i) => i.ticker === ticker);
    if (!issuer) return [];
    OHLCV_CACHE[ticker] = generateOHLCV(issuer.price);
  }
  return OHLCV_CACHE[ticker];
}

Object.assign(window, {
  MOCK_DATA: {
    ISSUERS,
    TRANSACTIONS,
    RELATIONSHIPS,
    NATURE_OF_TXN,
    SECURITY_DESIGNATIONS,
    OWNERSHIP_TYPES,
    INSIDER_NAMES,
    getOHLCV,
  },
});
