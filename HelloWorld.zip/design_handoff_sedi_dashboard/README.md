# Handoff: SEDI Insider Transactions Dashboard — UI Redesign

## Overview

This package contains the design references for redesigning the SEDI Insider Transactions Dashboard frontend. It covers three views:

1. **Transactions Dashboard** — filings table with filter bar, KPI summary, issuer activity heatmap, and most-active insiders leaderboard
2. **Ticker Detail** — issuer header with stats grid, real candlestick chart with insider buy/sell markers, and per-ticker filings table
3. **Market Overview** *(new)* — index tiles with sparklines, TSX sector performance heatmap, top movers (gainers / losers / most active), and aggregate insider sentiment chart

The redesign keeps the existing application's information architecture and API contract intact. It introduces a denser, "modern fintech" visual language (think Bloomberg / Koyfin) with IBM Plex typography, tabular numerics, and tighter row heights.

---

## About the Design Files

The files in this bundle are **design references** — interactive HTML/CSS/JSX prototypes that demonstrate the intended look, layout, and behavior. **They are not production code to drop into the codebase.**

The implementation target is the existing project stack:

- **Frontend**: Vue 3 + Vite + **PrimeVue 4 (Aura theme)** + Vue Router + Pinia + Axios
- **Backend**: Ruby on Rails 8 (API mode)
- **Database**: PostgreSQL 16
- **Charting**: `lightweight-charts@4` (already installed)
- **Enrichment**: Python FastAPI + yfinance microservice

The task is to **recreate these designs in the Vue codebase**, reusing PrimeVue components where they fit and building custom Vue components for the visualizations (heatmaps, leaderboards, sparklines, sentiment chart) that PrimeVue doesn't cover.

---

## Fidelity

**High-fidelity (hi-fi).** Colors, typography, spacing, border radii, and interactions are final. Implement pixel-perfectly against the prototype unless you find an issue or a better solution — in which case raise it before deviating.

---

## Tech Stack Integration Strategy

### Two paths — pick one before starting

**Path A (recommended): Keep PrimeVue Aura, reskin with new tokens.**
- Copy the design tokens from `styles.css` (`:root` block) into a global stylesheet.
- Override Aura's CSS variables where they conflict (e.g. accent color, border radius, font stacks).
- Use existing PrimeVue `DataTable`, `Select`, `DatePicker`, `InputNumber`, `FileUpload` — apply per-component class names via the `pt:` (pass-through) API or scoped overrides.
- Build the **non-PrimeVue** components (heatmap, leaderboard, sparkline tile, sector map, sentiment chart) as new standalone Vue components.

**Path B: Replace PrimeVue components in the redesigned views.**
- More visual control, but doubles the work. Only choose this if Aura is fighting the redesign too hard.

This handoff assumes **Path A** unless you decide otherwise.

### Frontend file structure (suggested)

```
frontend/src/
├── assets/
│   ├── styles.css            ← from prototype, design tokens + utility classes
│   └── fonts.css             ← IBM Plex Sans + Mono Google Fonts import
├── views/
│   ├── DashboardView.vue     ← from dashboard.jsx
│   ├── TickerView.vue        ← from ticker.jsx
│   └── MarketView.vue        ← from market.jsx (new route)
├── components/
│   ├── shared/
│   │   ├── KpiPanel.vue
│   │   └── FilterField.vue
│   ├── dashboard/
│   │   ├── FilingsSummaryPanel.vue
│   │   ├── IssuerHeatmap.vue
│   │   └── InsiderLeaderboard.vue
│   ├── ticker/
│   │   ├── TickerHeader.vue
│   │   ├── StatGrid.vue
│   │   └── CandleChart.vue
│   └── market/
│       ├── IndexTile.vue
│       ├── SectorMap.vue
│       ├── MoversPanel.vue
│       └── SentimentChart.vue
└── stores/
    ├── transactions.js       ← Pinia store, existing
    ├── ticker.js             ← Pinia store, existing
    └── market.js             ← Pinia store, new
```

### React → Vue translation patterns

| React (prototype) | Vue 3 (target) |
|---|---|
| `useState(initial)` | `ref(initial)` |
| `useMemo(() => …, [deps])` | `computed(() => …)` |
| `useEffect(() => fetch…, [])` | `onMounted(() => fetch…)` |
| `useEffect(() => …, [x, y])` | `watch([x, y], () => …)` |
| `useRef(null)` for DOM | `ref(null)` on `<div ref="el">` |
| `onClick={fn}` | `@click="fn"` |
| `{rows.map(r => …)}` | `<tr v-for="r in rows" :key="r.id">` |
| Component-local style obj | scoped `<style>` block or class |

State that's shared across views (filter state, ticker route param, etc.) moves into a **Pinia store**.

---

## Backend Additions

Most of the redesign works against your **existing API contract**. The new endpoints needed are limited to the Market tab and one aggregation.

### New endpoints

```
GET  /api/v1/market/indices             → proxy → Python /market/indices
GET  /api/v1/market/sectors             → proxy → Python /market/sectors
GET  /api/v1/market/movers?type=…       → proxy → Python /market/movers
GET  /api/v1/insider_sentiment          → Rails-only SQL aggregation
```

### Rails — `insider_sentiment`

Pure SQL aggregation over the `transactions` table. No enrichment service involved.

```ruby
# app/controllers/api/v1/transactions_controller.rb
def sentiment
  rows = Transaction
    .where(date_from..date_to)  # optional filter params
    .group(:transaction_date)
    .pluck(
      :transaction_date,
      Arel.sql("COUNT(*) FILTER (WHERE number_of_securities > 0)"),
      Arel.sql("COUNT(*) FILTER (WHERE number_of_securities < 0)"),
      Arel.sql("COALESCE(SUM(ABS(number_of_securities) * unit_price) FILTER (WHERE number_of_securities > 0), 0)"),
      Arel.sql("COALESCE(SUM(ABS(number_of_securities) * unit_price) FILTER (WHERE number_of_securities < 0), 0)")
    )
  render json: rows.map { |d, b, s, bv, sv|
    { date: d, buys: b, sells: s, buy_value: bv.to_f, sell_value: sv.to_f }
  }
end
```

### Python — yfinance market endpoints

```python
# enrichment/main.py
@app.get("/market/indices")
def indices():
    symbols = ["^GSPTSE", "^TX60", "^GSPC", "USDCAD=X", "CL=F", "GC=F"]
    out = []
    for sym in symbols:
        t = yf.Ticker(sym)
        hist = t.history(period="2mo", interval="1d")
        if hist.empty: continue
        last = float(hist["Close"].iloc[-1])
        prev = float(hist["Close"].iloc[-2]) if len(hist) > 1 else last
        spark = [float(v) for v in hist["Close"].tail(30).tolist()]
        out.append({
            "symbol": sym,
            "name": INDEX_NAMES[sym],
            "last": last,
            "prev": prev,
            "change_pct": ((last - prev) / prev * 100) if prev else 0,
            "spark": spark,
        })
    return out

@app.get("/market/sectors")
def sectors():
    # Use TSX sector ETFs as proxies for sector performance
    etfs = {
        "Financials": "XFN.TO", "Energy": "XEG.TO", "Materials": "XMA.TO",
        "Industrials": "XIN.TO", "Technology": "XIT.TO",
        "Consumer Discretionary": "XCD.TO", "Consumer Staples": "XST.TO",
        "Utilities": "XUT.TO", "Real Estate": "XRE.TO",
        "Communication": "XCM.TO", "Health Care": "XHC.TO",
    }
    # Pull 1d / 1w / 1m / ytd returns from each ETF, plus index weights
    # (weights can be hardcoded from S&P/TSX Composite methodology)
    ...

@app.get("/market/movers")
def movers(type: str = "gainers"):
    # Either: pull TSX Composite constituent list and rank by daily % change
    # Or:     keep a curated watchlist and screen yfinance for it
    ...
```

Each Python endpoint is mirrored in Rails as a thin proxy (same pattern as the existing `/api/v1/issuers/:ticker/ohlcv`).

---

## View Specs

### 1. App Shell (`App.vue`)

- **Layout**: `100vh` flex column. Sticky dark header on top, single `<main>` below that fills remaining height and is `overflow: hidden`. Each view controls its own scroll.
- **Header height**: 56px
- **Header background**: `#161726` (deep navy, near-black)
- **Header contents** (left to right):
  - Brand block (right border divider): 26×26 gradient mark (linear-gradient 135deg, `oklch(60% 0.18 254)` → `oklch(50% 0.18 270)`) + brand name "SEDI Dashboard" 14px 600 weight + "v1.0" version sub
  - Tab nav: `Transactions`, `Market`, `Ticker {SYMBOL}` (Ticker tab is disabled/dimmed when no ticker selected)
  - Right-aligned status meta: green pulse dot + "enrichment online", "api v1", live timestamp — IBM Plex Mono 11px
- **Tab styling**: 13px text, muted white (rgba(255,255,255,0.65)) inactive, full white active, with a 2px underline accent line (`oklch(70% 0.16 254)`) on active tab anchored to the bottom of the tab

### 2. Transactions Dashboard (`DashboardView.vue`)

**Layout** (top to bottom):

1. **View header** (24px horizontal padding) — title "Canadian Insider Transactions" (22px / 600), subtitle "SEDI · Q1 2025 dataset · sedi_2025_01_1.csv · 420 filings" (Plex Mono 12px muted). Right side: quick stats `N issuers / N insiders / N filings`.

2. **Stats strip** (24px horizontal margins, 12px gap): 3-column grid `220px 1fr 320px`
   - **Filings Summary panel** (left, 220px wide): Stack of KPI rows — Acquisitions (green count + dollar sub), Dispositions (red count + dollar sub), Buy/Sell ratio.
   - **Issuer Activity heatmap** (center, flex): Top 12 issuers by filing volume. Slice-and-dice into 2 rows of 6. Each cell sized by `count / row_total`. Background color encodes net buy (green) vs net sell (red) value, intensity scaled to max abs net. Shows sector label (small uppercase) + ticker (mono 14px 600) + filings count + net $.
   - **Most Active Insiders leaderboard** (right, 320px): Top 8 insiders by filing count. Each row: rank, name + tickers count sub-line, 70px buy/sell split bar (green segment for buys, red segment for sells, widths normalized to top insider's total), filing count.

3. **Filter bar** (24px horizontal margins, 8px border-radius, `--bg-filter` background, 12px/14px padding): flex-wrap row of `FilterField`s — Date From, Date To, Ticker, Insider, Transaction Type (custom dropdown showing code + description), 1px vertical divider, Min Insiders / Ticker, push-right Clear + Apply Filters buttons.

4. **Main DataTable** (24px horizontal margins, flex: 1 fill, internal scroll):
   - **Toolbar row** (38px, `--bg-elev`): "Showing N filings" · active filter chips (with × dismiss) · push-right "Sort: {field} {↑↓}"
   - **Table** — sticky header. Striped even rows. Hover highlight.
   - **Columns**: Filed (mono date 92px) · Txn Date (mono date 92px) · Insider · Relationship (first only + "+N" pill if multiple) · Ticker (mono pill — clickable, navigates to TickerView) · Issuer (muted) · Security (muted) · Txn Type (code pill + description) · Shares (right-aligned, green ▲ / red ▼ + signed comma-separated count) · Price (right-aligned mono $) · Balance (right-aligned mono int)
   - **Pagination footer** (42px, `--bg-elev`): "Start–End of Total" · push-right page number buttons (« ‹ 1 … 5 › ») · "25 per page" select

**Behavior**:
- Filter changes reset page to 1
- All filter state belongs in a Pinia `transactions` store so it survives navigation
- Sort: click column header to toggle asc/desc; default sort is `filing_date desc`
- "Min insiders" filter: SQL subquery on the issuer (`COUNT(DISTINCT insider_id) ≥ N`), already exists in your backend
- Clicking the ticker pill: `router.push({ name: 'ticker', params: { symbol: row.ticker } })`
- Clicking a leaderboard row: pre-fills the Insider filter with the insider's last name and re-applies

### 3. Ticker Detail View (`TickerView.vue`)

**Layout**:

1. **Header section** (22px / 24px padding, 1px bottom border):
   - Left: 60×60 dark navy ticker badge — mono 20px 600 white text, 6px radius (e.g. "TD.TO")
   - Middle: back link ("← Back to transactions") + issuer name (26px / 600) + meta row (sector chip, website link with external-link icon, "SEDI · TSX" mono note) + description (max-width 760px, 13px / 1.55 line-height, muted)
   - Right: 4-column stat grid — Last (price + day change % colored), Filings (count + insiders sub), Buys / Sells (green count / red count + $ values), Net Insider $ (colored signed magnitude)

2. **Chart section** (`CandleChart.vue` — see below)

3. **Filings table** — same DataTable component, pre-filtered to this ticker, max-height 520px

#### `CandleChart.vue` — `lightweight-charts@4` integration

**Toolbar** (42px, `--bg-elev` background, 1px bottom border):
- Period segmented button group: `1M / 3M / 6M / 1Y / 2Y`
- Buys toggle (green ▲ + "Buys" label)
- Sells toggle (red ▼ + "Sells" label)
- Push-right OHLC hover readout (Plex Mono): `D 2025-02-14  O 82.43  H 82.91  L 81.87  C 82.55`

**Chart** (380px height, transparent background — picks up `--bg-panel`):

```js
import { createChart, LineStyle } from 'lightweight-charts'

const chart = createChart(containerEl, {
  autoSize: true,
  layout: {
    background: { type: 'solid', color: 'transparent' },
    textColor: isDark ? '#9a9ea8' : '#61656f',
    fontFamily: '"IBM Plex Mono", ui-monospace, monospace',
    fontSize: 11,
  },
  grid: {
    vertLines: { color: isDark ? '#1c1f2a' : '#eeeeea' },
    horzLines: { color: isDark ? '#1c1f2a' : '#eeeeea' },
  },
  rightPriceScale: { borderColor: isDark ? '#232634' : '#e4e4e0' },
  timeScale: { borderColor: isDark ? '#232634' : '#e4e4e0' },
  crosshair: {
    mode: 1,
    vertLine: { style: LineStyle.Dashed, /* ... */ },
    horzLine: { style: LineStyle.Dashed, /* ... */ },
  },
})

const series = chart.addCandlestickSeries({
  upColor: '#16a34a',   downColor: '#dc2626',
  borderUpColor: '#16a34a', borderDownColor: '#dc2626',
  wickUpColor: '#16a34a', wickDownColor: '#dc2626',
})

series.setData(ohlcv) // {time: 'YYYY-MM-DD', open, high, low, close}
series.setMarkers(insiderMarkers)
```

**Insider markers** — built from `/api/v1/issuers/:ticker/trade_events`:
- Dedupe to one buy + one sell per date (per the existing backend behavior)
- Per-date buy marker: `{ time, position: 'belowBar', color: '#16a34a', shape: 'arrowUp', text: 'B' + (count > 1 ? '·' + count : '') }`
- Per-date sell marker: `{ time, position: 'aboveBar', color: '#dc2626', shape: 'arrowDown', text: 'S' + (count > 1 ? '·' + count : '') }`
- Filter out marker dates that aren't in the chart's data range (lightweight-charts will throw)

**Crosshair subscribe** — update toolbar OHLC readout:
```js
chart.subscribeCrosshairMove((param) => {
  if (!param.time) { hover.value = null; return }
  hover.value = { time: param.time, ...param.seriesData.get(series) }
})
```

**Cleanup**: call `chart.remove()` on `onBeforeUnmount`. Rebuild chart when navigating between tickers (use `:key="ticker"` on the chart component).

### 4. Market Overview (`MarketView.vue`)

**Layout** (24px horizontal padding):

1. **View header**: title "Canadian Market Overview" + subtitle + right-aligned "As of {timestamp}" with pulsing green dot.

2. **Index strip** (6-column grid, 12px gap, 4px top margin): 6 `IndexTile.vue` cards. Each card: symbol (`^GSPTSE` mono 10.5px), name ("S&P/TSX Composite" 12px 500), last value (mono 20px 500), change row (`▲ +77.03 (+0.31%)` colored), and 70×32 SVG sparkline absolute-positioned top-right.

3. **Main grid** (`1fr 360px`, 16px gap, 16px top margin):
   - **Left column**: vertical stack of two panels
     - **TSX Sector Performance** heatmap — proportional treemap. 11 GICS sectors. Top 5 by weight on row 1, rest on row 2. Cell `grid-column: span N` where N is proportional to sector weight (summing to 12 columns per row). Background color encodes performance for the active metric (1D / 1W / 1M / YTD — segmented toggle in panel header). Each cell shows sector name (12px 600), value (mono 16px 500, signed %), weight (mono 10px muted, inline after value).
     - **Aggregate Insider Sentiment** (custom SVG) — top half: cumulative net insider $ line + area fill (green). Bottom half: side-by-side daily buy/sell vertical bars per date. Split by a 1px divider line. Y-axis: max cum value (top), 0 (mid), max daily count (bottom). X-axis: month labels (Jan / Feb / Mar). Crosshair on hover with tooltip showing date, buy count + value, sell count + value, cumulative net.
     - Above the chart: stats row — Acquisitions (count + "vs N disp" sub), Buy/Sell ratio + "Net bullish/bearish" sub, Net insider $ (colored).
   - **Right column**: `MoversPanel.vue`
     - Tab strip: Top Gainers / Top Losers / Most Active (38px, full-width split, active tab has 2px accent underline)
     - Row list: ticker pill (mono) + name (muted, with `● SEDI` accent dot if ticker exists in `transactions` table) + last price OR volume (depending on active tab) + colored % change. Click row to navigate to TickerView if ticker is in SEDI dataset.

**Sparkline implementation** (pure SVG, no library):
```js
const points = spark.map((v, i) => {
  const x = (i / (spark.length - 1)) * 70
  const y = 32 - ((v - min) / (max - min || 1)) * 32
  return `${x},${y}`
}).join(' ')
// <polyline points={points} stroke="var(--buy)" /* or --sell */ stroke-width="1.5" fill="none"/>
```

**Sentiment chart** — read directly from `market.jsx` `InsiderSentimentPanel` for the full SVG construction (path math, bar layout, axis labels). The viewBox is `880×200`. **Important**: when parsing date strings for month labels, append `T12:00:00` to avoid timezone rolling the ISO date back a day:
```js
new Date(dateStr + 'T12:00:00').toLocaleDateString('en-CA', { month: 'short' })
```

---

## Design Tokens

All tokens are defined as CSS custom properties in `styles.css` `:root` (light) and `[data-theme="dark"]` (dark). Density also tokenized via `[data-density="compact|default|comfortable"]`.

### Colors — Light theme

| Token | Value | Used for |
|---|---|---|
| `--bg` | `#f5f5f3` | Page background |
| `--bg-panel` | `#ffffff` | Panels / cards |
| `--bg-elev` | `#fafafa` | Table header, toolbar, elevated areas |
| `--bg-filter` | `#f1f1ef` | Filter bar background |
| `--bg-row-hover` | `#f7f7f5` | Hovered rows |
| `--bg-row-stripe` | `#fafaf8` | Even rows |
| `--fg` | `#14161c` | Primary text |
| `--fg-muted` | `#61656f` | Secondary text |
| `--fg-faint` | `#94989f` | Tertiary / placeholder text |
| `--border` | `#e4e4e0` | Default borders |
| `--border-strong` | `#d4d4d0` | Emphasized borders / dividers |
| `--navy` | `#161726` | Header, primary buttons, ticker badge |
| `--navy-2` | `#1f2235` | Hover state for navy |
| `--accent` | `oklch(58% 0.14 254)` | Focus rings, links, active accents |
| `--buy` | `oklch(56% 0.16 148)` | Buy / acquisitions / positive |
| `--sell` | `oklch(56% 0.18 28)` | Sell / dispositions / negative |
| `--buy-bg` | `oklch(94% 0.05 148)` | Buy backgrounds |
| `--sell-bg` | `oklch(95% 0.05 28)` | Sell backgrounds |

### Colors — Dark theme (`[data-theme="dark"]`)

| Token | Value |
|---|---|
| `--bg` | `#0c0d14` |
| `--bg-panel` | `#14161f` |
| `--bg-elev` | `#181a25` |
| `--bg-filter` | `#181a25` |
| `--bg-row-hover` | `#1b1d29` |
| `--bg-row-stripe` | `#16182160` |
| `--fg` | `#e6e6e3` |
| `--fg-muted` | `#9a9ea8` |
| `--fg-faint` | `#6b6f7a` |
| `--border` | `#232634` |
| `--border-strong` | `#2d3043` |
| `--navy` | `#0a0b13` |
| `--navy-2` | `#14161f` |

### Heatmap color scales (computed)

- **Buy intensity** (issuer activity heatmap & sector positive performance):
  `oklch(${68 - intensity*18}% ${0.04 + intensity*0.14} 148)` for sector map
  `oklch(${65 - intensity*12}% ${0.05 + intensity*0.13} 148)` for issuer heatmap
- **Sell intensity** (same, hue 28 instead of 148, slightly higher max chroma `0.17` / `0.16`)
- Foreground text flips to white when `intensity > 0.35` (sector) or `> 0.4` (issuer)

### Typography

- **Font families**:
  - `--font-sans`: `"IBM Plex Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`
  - `--font-mono`: `"IBM Plex Mono", ui-monospace, "SF Mono", Menlo, Consolas, monospace`
- **Weights used**: 400 (default), 500 (semi), 600 (titles), 700 (rarely)
- **Tabular numerics**: every number in the UI uses `font-feature-settings: "tnum" 1; font-variant-numeric: tabular-nums;` via the `.num` utility class — apply to all dollar amounts, counts, prices, dates rendered numerically.
- **Body size**: 12.5px (compact, default) / 13px (default density) / 13px (comfortable)
- **Cell padding** scales with density via `--cell-py` (6 / 8 / 12) and `--cell-px` (10 / 12 / 14)

### Spacing & radii

- Border radius: 8px panels, 6px buttons/inputs, 4px small chips/cells, 3px tiny pills
- Standard panel padding: 12px–16px
- Standard view horizontal padding: 24px
- Stats strip / filter bar gap: 12px
- Table row heights: 30 / 32 / 36 / 44 px depending on density

### Shadows

- `--shadow-sm`: `0 1px 0 rgba(20, 22, 28, 0.04)`
- `--shadow-md`: `0 4px 16px -8px rgba(20, 22, 28, 0.12), 0 1px 0 rgba(20, 22, 28, 0.04)`
- `--shadow-lg`: `0 20px 60px -20px rgba(20, 22, 28, 0.28)` (only for dropdowns / overlays)

---

## Interactions & Behavior

### Dashboard

- **Filter changes** debounce-apply (200ms) or apply on `Enter` / `Apply Filters` button. Reset page to 1 on any filter change.
- **Active filter chips** appear in the table toolbar; clicking the `×` clears that filter.
- **Column sort** click toggles asc/desc. Sort indicator (`▲` / `▼`) renders next to header label in accent color.
- **Ticker pill** click stops event propagation and navigates to `/ticker/{symbol}`.
- **Leaderboard row** click pre-fills the Insider filter and re-runs the query.
- **Heatmap cell** click navigates to that ticker's detail page.

### Ticker

- **Period buttons** filter chart OHLCV data; chart `fitContent()` after data swap.
- **Buy / Sell toggles** rebuild markers (don't rebuild the whole chart).
- **Crosshair hover** updates the OHLC readout in the toolbar via `subscribeCrosshairMove`.
- **Navigating to a different ticker**: destroy and recreate the chart (cleanest — use `<CandleChart :key="ticker" />`).

### Market

- **Period toggle in sector heatmap** swaps the metric used for cell color + value.
- **Movers tab switch** swaps the list (no API re-fetch — all three lists are returned from one `/market/movers` call, or cached).
- **Mover row** click navigates to TickerView only if ticker is in SEDI dataset (the `● SEDI` indicator).
- **Sentiment chart hover** — `onMouseMove` on the SVG: convert pixel X back to date by linear interpolation, find closest data point, show crosshair line + tooltip card. Tooltip position clamps to stay inside the panel.

### Theming & density

- Tweak panel in the prototype is for prototype only — not part of the production app. Hardcode light theme + default density unless you decide to offer a user preference.
- If offering: persist `theme` and `density` to localStorage; apply via `document.documentElement.dataset.theme` and `…dataset.density`. CSS variables do the rest.

---

## State Management (Pinia)

```js
// stores/transactions.js
export const useTransactionsStore = defineStore('transactions', {
  state: () => ({
    filters: {
      dateFrom: '', dateTo: '', ticker: '', insiderName: '',
      natureOfTransactionId: null, minInsiders: null,
    },
    sort: { key: 'filing_date', direction: 'desc' },
    page: 1, perPage: 50,
    rows: [], total: 0, loading: false,
    // aggregations for the strip
    summary: { buys: 0, sells: 0, buyValue: 0, sellValue: 0 },
    topIssuers: [],     // for heatmap
    topInsiders: [],    // for leaderboard
  }),
  actions: {
    async fetch() {
      this.loading = true
      const { data } = await axios.get('/api/v1/transactions', { params: { ...this.filters, ...this.sort, page: this.page, per_page: this.perPage } })
      this.rows = data.transactions
      this.total = data.total
      // ... aggregate summary, top issuers, top insiders client-side from the page slice,
      //     OR add dedicated endpoints for those if the dataset grows beyond a single page.
      this.loading = false
    },
    setFilter(key, value) { this.filters[key] = value; this.page = 1; this.fetch() },
    clearFilters() { /* reset and fetch */ },
  },
})
```

```js
// stores/market.js
export const useMarketStore = defineStore('market', {
  state: () => ({ indices: [], sectors: [], gainers: [], losers: [], mostActive: [], sentiment: [], asOf: null }),
  actions: {
    async fetchAll() {
      const [idx, sec, gain, los, act, sent] = await Promise.all([
        axios.get('/api/v1/market/indices'),
        axios.get('/api/v1/market/sectors'),
        axios.get('/api/v1/market/movers?type=gainers'),
        axios.get('/api/v1/market/movers?type=losers'),
        axios.get('/api/v1/market/movers?type=active'),
        axios.get('/api/v1/insider_sentiment'),
      ])
      // ...
    },
  },
})
```

---

## Suggested Build Order

1. **Tokens & fonts first** — drop `styles.css` and Google Fonts import into `main.js`. The existing app immediately picks up the new visual language without any refactoring.
2. **Dashboard header + stats strip** — build the 3 panels (`FilingsSummaryPanel`, `IssuerHeatmap`, `InsiderLeaderboard`) as new Vue components, slot above the existing `DataTable` in `DashboardView.vue`. Aggregations can be computed client-side from the current page's rows initially; promote to dedicated endpoints if the dataset outgrows that.
3. **Dashboard filter bar restyle** — apply new field styling. Keep existing PrimeVue inputs but wrap each in a `<FilterField label="...">` component to add the small uppercase label. Replace the transaction-type dropdown with PrimeVue's `Select` styled to match (or rebuild as a custom component if the styling fight isn't worth it).
4. **DataTable restyle** — apply new column styling via PrimeVue's `pt:` API or scoped CSS. Add the toolbar row (sorting indicator, active filter chips) above the existing PrimeVue DataTable.
5. **Ticker view** — restyle the header into the new layout. Replace the TradingView iframe fallback with the redesigned `CandleChart` component (you already have `lightweight-charts` installed).
6. **Market view** — new route `/market`. Build `IndexTile`, `SectorMap`, `MoversPanel`, `SentimentChart` components. Add Pinia store. Add new Rails + Python endpoints.
7. **Tab nav** — extend the existing `TabMenu` to include the Market tab.

---

## Files in This Bundle

- `SEDI Dashboard.html` — entry point. Open in a browser to see the working prototype.
- `styles.css` — design tokens + utility classes. **Copy this verbatim into the Vue project.**
- `data.js` — mock SEDI data generator (transactions, issuers, OHLCV). Reference for data shapes; do not copy.
- `market-data.js` — mock market data generator. Reference for data shapes; do not copy.
- `app.jsx` — root component + router + theme/density tweaks. **Reference for layout patterns and tab nav.**
- `components.jsx` — shared React components: `DataTable`, `Select`, `Field`, `Icon`, `fmt` formatters. **Reuse the `fmt` helpers** in Vue; use PrimeVue equivalents for `DataTable` and `Select`.
- `dashboard.jsx` — Dashboard view. **Translate to `DashboardView.vue` + components.**
- `ticker.jsx` — Ticker detail view + `CandleChart`. **Translate to `TickerView.vue` + `CandleChart.vue`.**
- `market.jsx` — Market view + all market components. **Translate to `MarketView.vue` + the 4 market components.**
- `tweaks-panel.jsx` — prototype-only theming UI. **Do not port.** Hardcode light theme in the Vue app unless you add a preference.

## Assets

No image assets. All graphics are SVG built inline (sparklines, sector heatmap, insider sentiment chart) or rendered by `lightweight-charts` (the candlestick chart). Icons in the prototype are tiny inline SVGs (search, external link, arrow); replicate them or substitute equivalents from your existing icon system (e.g. PrimeIcons).

## Mock Data Shapes (for reference)

A transaction row returned from `GET /api/v1/transactions`:
```js
{
  id: 1,
  sedi_transaction_id: 8000000,
  transaction_date: "2025-01-15",
  filing_date: "2025-01-18",
  number_of_securities: -6540,        // negative for disposals
  unit_price: 85.29,
  balance: 120760,
  insider_name: "McLeod, Fiona J.",
  issuer_ticker: "TD.TO",
  issuer_name: "Toronto-Dominion Bank",
  relationships: ["Issuer", "Director of Issuer"],
  security_designation: "Stock Options",
  ownership_type: { category: "Direct", entity_name: null },
  nature_of_transaction: { code: "38", description: "Redemption, retraction, cancellation, repurchase" },
}
```

An OHLCV row from `/api/v1/issuers/:ticker/ohlcv`:
```js
{ date: "2025-03-21", open: 82.43, high: 82.91, low: 81.87, close: 82.55, volume: 4_500_000 }
```

A market index from `/api/v1/market/indices`:
```js
{
  symbol: "^GSPTSE", name: "S&P/TSX Composite",
  last: 24850.0, prev: 24773.0, change_pct: 0.31,
  spark: [24650, 24681, /* ... 30 daily closes ... */, 24850],
}
```

A sector from `/api/v1/market/sectors`:
```js
{ name: "Financials", weight: 30.4, day: 0.42, week: 1.18, month: 2.95, ytd: 9.8 }
```

A mover from `/api/v1/market/movers?type=gainers`:
```js
{ ticker: "WEED.TO", name: "Canopy Growth Corp", last: 4.87, chg: 12.41, vol: 8_400_000 }
```

A sentiment row from `/api/v1/insider_sentiment`:
```js
{ date: "2025-01-15", buys: 4, sells: 2, buy_value: 318_400.0, sell_value: 124_800.0 }
```

---

## Open Questions / Decisions Needed

1. **PrimeVue Aura — reskin or replace?** Recommended: reskin (Path A above).
2. **Insider sentiment data range** — current prototype computes cumulative net over the entire dataset. For production with growing data, decide: rolling 90 days? user-selectable period?
3. **Movers data source** — yfinance doesn't expose a TSX gainers/losers screener directly. Either curate a TSX watchlist (~50 tickers) and rank by daily % change, or pull S&P/TSX Composite constituents via a third-party list. Decide before implementing `/market/movers`.
4. **Sector weights** — hardcode from S&P/TSX Composite methodology (rebalanced quarterly) or pull from an index data provider.
5. **Caching** — Python market endpoints should cache yfinance responses (Redis or in-memory) with a short TTL (5 minutes for indices, longer for sectors). Rate limits will hit otherwise.
