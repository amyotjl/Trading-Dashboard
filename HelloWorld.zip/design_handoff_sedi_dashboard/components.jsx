/* global React */
const { useState, useEffect, useRef, useMemo, useCallback, useLayoutEffect } = React;

// ---------- formatters ----------
const fmt = {
  int: (n) => (n == null ? "—" : new Intl.NumberFormat("en-CA").format(Math.abs(n))),
  signed: (n) => (n == null ? "—" : (n > 0 ? "+" : n < 0 ? "−" : "") + new Intl.NumberFormat("en-CA").format(Math.abs(n))),
  money: (n) => (n == null ? "—" : "$" + n.toFixed(2)),
  moneyBig: (n) => {
    if (n == null) return "—";
    if (Math.abs(n) >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
    if (Math.abs(n) >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
    if (Math.abs(n) >= 1e3) return "$" + (n / 1e3).toFixed(1) + "K";
    return "$" + n.toFixed(2);
  },
  date: (s) => {
    if (!s) return "—";
    const d = new Date(s);
    return d.toLocaleDateString("en-CA", { year: "numeric", month: "short", day: "2-digit" });
  },
  dateShort: (s) => {
    if (!s) return "—";
    const d = new Date(s);
    return d.toLocaleDateString("en-CA", { month: "short", day: "2-digit" });
  },
};

// ---------- Select (custom dropdown, more compact than native) ----------
function Select({ value, onChange, options, placeholder = "All", width = 260, showCode = false }) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef(null);
  const [pos, setPos] = useState({ top: 0, left: 0, width });

  useLayoutEffect(() => {
    if (open && btnRef.current) {
      const r = btnRef.current.getBoundingClientRect();
      setPos({ top: r.bottom + 4, left: r.left, width: Math.max(r.width, width) });
    }
  }, [open, width]);

  const selected = options.find((o) => String(o.value) === String(value));

  return (
    <>
      <button
        ref={btnRef}
        className="field-input"
        onClick={() => setOpen((o) => !o)}
        style={{ width, textAlign: "left", display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", background: "var(--bg-panel)" }}
      >
        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: selected ? "var(--fg)" : "var(--fg-faint)" }}>
          {selected ? (showCode && selected.code ? <><span style={{ fontFamily: "var(--font-mono)", color: "var(--fg-muted)", marginRight: 6 }}>{selected.code}</span>{selected.label}</> : selected.label) : placeholder}
        </span>
        <span style={{ color: "var(--fg-faint)", marginLeft: 6 }}>▾</span>
      </button>
      {open && (
        <>
          <div className="dropdown-overlay" onClick={() => setOpen(false)} />
          <div className="select-menu" style={{ top: pos.top, left: pos.left, width: pos.width }}>
            <div className="item" onClick={() => { onChange(null); setOpen(false); }}>
              <span style={{ color: "var(--fg-faint)" }}>—</span>
              <span>{placeholder}</span>
            </div>
            {options.map((o) => (
              <div
                key={o.value}
                className={"item" + (String(o.value) === String(value) ? " active" : "")}
                onClick={() => { onChange(o.value); setOpen(false); }}
              >
                {showCode && o.code && <span className="code">{o.code}</span>}
                <span>{o.label}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}

// ---------- DataTable ----------
function DataTable({ columns, rows, sort, onSort, page, pageSize, total, onPage, onPageSize, onRowClick, scrollHeight }) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const end = Math.min(total, page * pageSize);

  const pageButtons = useMemo(() => {
    const out = [];
    const window = 2;
    let lastShown = 0;
    for (let p = 1; p <= totalPages; p++) {
      if (p === 1 || p === totalPages || (p >= page - window && p <= page + window)) {
        if (lastShown && p - lastShown > 1) out.push("...");
        out.push(p);
        lastShown = p;
      }
    }
    return out;
  }, [page, totalPages]);

  return (
    <>
      <div className="table-scroll" style={scrollHeight ? { maxHeight: scrollHeight } : null}>
        <table className="data">
          <thead>
            <tr>
              {columns.map((c) => (
                <th
                  key={c.key}
                  className={c.numeric ? "num" : ""}
                  style={c.width ? { width: c.width } : null}
                  onClick={() => c.sortable !== false && onSort && onSort(c.key)}
                >
                  {c.label}
                  {sort && sort.key === c.key && (
                    <span className="sort-ind">{sort.dir === "asc" ? "▲" : "▼"}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="empty-state">
                  No transactions match the current filters.
                </td>
              </tr>
            ) : (
              rows.map((r, idx) => (
                <tr key={r.id || idx} onClick={() => onRowClick && onRowClick(r)} style={onRowClick ? { cursor: "pointer" } : null}>
                  {columns.map((c) => (
                    <td key={c.key} className={c.numeric ? "num" : c.mono ? "mono" : ""}>
                      {c.render ? c.render(r) : r[c.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div className="pagination">
        <span>
          <b style={{ color: "var(--fg)" }}>{start.toLocaleString()}</b>–<b style={{ color: "var(--fg)" }}>{end.toLocaleString()}</b> of <b style={{ color: "var(--fg)" }}>{total.toLocaleString()}</b>
        </span>
        <span className="spacer" />
        <button className="page-btn" disabled={page === 1} onClick={() => onPage(1)}>«</button>
        <button className="page-btn" disabled={page === 1} onClick={() => onPage(page - 1)}>‹</button>
        {pageButtons.map((p, i) =>
          p === "..." ? (
            <span key={"e" + i} style={{ color: "var(--fg-faint)", padding: "0 2px" }}>…</span>
          ) : (
            <button key={p} className={"page-btn" + (p === page ? " active" : "")} onClick={() => onPage(p)}>{p}</button>
          )
        )}
        <button className="page-btn" disabled={page === totalPages} onClick={() => onPage(page + 1)}>›</button>
        <button className="page-btn" disabled={page === totalPages} onClick={() => onPage(totalPages)}>»</button>
        <span style={{ marginLeft: 8 }}>
          <select className="page-size" value={pageSize} onChange={(e) => onPageSize(Number(e.target.value))}>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span style={{ marginLeft: 4 }}>per page</span>
        </span>
      </div>
    </>
  );
}

// ---------- Filter bar helpers ----------
function Field({ label, children, width }) {
  return (
    <div className="field" style={width ? { width } : null}>
      <div className="field-label">{label}</div>
      {children}
    </div>
  );
}

// ---------- shared SVG icons ----------
const Icon = {
  Arrow: (p) => <svg width="10" height="10" viewBox="0 0 10 10" {...p}><path d="M2 4l3 3 3-3" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  Search: (p) => <svg width="12" height="12" viewBox="0 0 12 12" {...p}><circle cx="5" cy="5" r="3.5" stroke="currentColor" strokeWidth="1.4" fill="none"/><path d="M8 8l2.5 2.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>,
  External: (p) => <svg width="11" height="11" viewBox="0 0 11 11" {...p}><path d="M4 2H2v7h7V7M6 2h3v3M9 2L5 6" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

Object.assign(window, {
  fmt, Select, DataTable, Field, Icon,
});
