/* global React, MOCK_DATA, fmt, DataTable, Icon, LightweightCharts */
const { useState, useMemo, useEffect, useRef, useLayoutEffect } = React;

function TickerView({ ticker, onBack, onOpenTicker, themeMode, accent }) {
  const issuer = useMemo(() => MOCK_DATA.ISSUERS.find((i) => i.ticker === ticker), [ticker]);
  const ohlcv = useMemo(() => MOCK_DATA.getOHLCV(ticker), [ticker]);
  const allTxns = useMemo(() => MOCK_DATA.TRANSACTIONS.filter((t) => t.issuer_ticker === ticker), [ticker]);

  const [period, setPeriod] = useState("2y");
  const [showBuys, setShowBuys] = useState(true);
  const [showSells, setShowSells] = useState(true);

  const [sort, setSort] = useState({ key: "filing_date", dir: "desc" });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  useEffect(() => { setPage(1); }, [ticker]);

  // Filter chart data by period
  const filteredOhlcv = useMemo(() => {
    if (!ohlcv.length) return [];
    const lastDate = new Date(ohlcv[ohlcv.length - 1].date);
    let cutoff = new Date(0);
    if (period === "1m") cutoff = new Date(lastDate.getTime() - 30 * 86400000);
    else if (period === "3m") cutoff = new Date(lastDate.getTime() - 90 * 86400000);
    else if (period === "6m") cutoff = new Date(lastDate.getTime() - 180 * 86400000);
    else if (period === "1y") cutoff = new Date(lastDate.getTime() - 365 * 86400000);
    else cutoff = new Date(lastDate.getTime() - 730 * 86400000);
    return ohlcv.filter((c) => new Date(c.date) >= cutoff);
  }, [ohlcv, period]);

  // KPIs
  const stats = useMemo(() => {
    const buys = allTxns.filter((t) => t.number_of_securities > 0);
    const sells = allTxns.filter((t) => t.number_of_securities < 0);
    const sum = (rs) => rs.reduce((acc, r) => acc + Math.abs(r.number_of_securities) * (r.unit_price || 0), 0);
    const lastPrice = ohlcv.length ? ohlcv[ohlcv.length - 1].close : null;
    const prevPrice = ohlcv.length > 1 ? ohlcv[ohlcv.length - 2].close : lastPrice;
    const dayChange = lastPrice != null && prevPrice != null ? ((lastPrice - prevPrice) / prevPrice) * 100 : null;
    return {
      lastPrice,
      dayChange,
      totalFilings: allTxns.length,
      buys: buys.length,
      sells: sells.length,
      buyValue: sum(buys),
      sellValue: sum(sells),
      netValue: sum(buys) - sum(sells),
      insiders: new Set(allTxns.map((t) => t.insider_name)).size,
    };
  }, [allTxns, ohlcv]);

  // Sort + paginate txns
  const sortedTxns = useMemo(() => {
    const out = [...allTxns];
    const { key, dir } = sort;
    out.sort((a, b) => {
      let av, bv;
      if (key === "nature") { av = a.nature_of_transaction.code; bv = b.nature_of_transaction.code; }
      else if (key === "shares") { av = a.number_of_securities; bv = b.number_of_securities; }
      else if (key === "price") { av = a.unit_price ?? 0; bv = b.unit_price ?? 0; }
      else { av = a[key]; bv = b[key]; }
      if (av < bv) return dir === "asc" ? -1 : 1;
      if (av > bv) return dir === "asc" ? 1 : -1;
      return 0;
    });
    return out;
  }, [allTxns, sort]);

  const paged = useMemo(() => sortedTxns.slice((page - 1) * pageSize, page * pageSize), [sortedTxns, page, pageSize]);

  if (!issuer) {
    return (
      <div className="view">
        <div className="empty-state">
          Ticker not found.{" "}
          <a onClick={onBack} style={{ cursor: "pointer" }}>Go back</a>
        </div>
      </div>
    );
  }

  const columns = [
    { key: "filing_date", label: "Filed", width: 92, render: (r) => <span className="mono">{fmt.dateShort(r.filing_date)}</span> },
    { key: "transaction_date", label: "Txn Date", width: 92, render: (r) => <span className="mono">{fmt.dateShort(r.transaction_date)}</span> },
    { key: "insider_name", label: "Insider", render: (r) => <span>{r.insider_name}</span> },
    { key: "relationships", label: "Relationship", sortable: false, render: (r) => (
      <span className="rel-cell">{r.relationships[0].replace(/^\d+\s*-\s*/, "")}{r.relationships.length > 1 && <span className="more">+{r.relationships.length - 1}</span>}</span>
    )},
    { key: "security_designation", label: "Security", render: (r) => <span style={{ color: "var(--fg-muted)" }}>{r.security_designation}</span> },
    { key: "nature", label: "Txn Type", render: (r) => (
      <div className="txn-type-cell">
        <span className="code">{r.nature_of_transaction.code}</span>
        <span className="desc">{r.nature_of_transaction.description}</span>
      </div>
    )},
    { key: "shares", label: "Shares", numeric: true, render: (r) => (
      <span className={"shares-cell " + (r.number_of_securities > 0 ? "shares-pos" : "shares-neg")}>
        <span className="ind">{r.number_of_securities > 0 ? "▲" : "▼"}</span>{fmt.signed(r.number_of_securities)}
      </span>
    )},
    { key: "price", label: "Price", numeric: true, render: (r) => fmt.money(r.unit_price) },
    { key: "balance", label: "Balance", numeric: true, render: (r) => fmt.int(r.balance) },
  ];

  const handleSort = (key) => {
    setSort((s) => s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "desc" });
  };

  return (
    <div className="view ticker-view">
      <div className="ticker-header">
        <div className="ticker-badge">{ticker}</div>
        <div className="ticker-title-wrap">
          <div className="back-link" onClick={onBack}>← Back to transactions</div>
          <h1 className="ticker-title">{issuer.name}</h1>
          <div className="ticker-meta-row">
            <span className="sector-chip">{issuer.sector}</span>
            <a href={`https://${issuer.home_page}`} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              {issuer.home_page} <Icon.External />
            </a>
            <span style={{ color: "var(--fg-faint)" }}>·</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5 }}>SEDI · TSX</span>
          </div>
          <p className="ticker-description">{issuer.description}</p>
        </div>
        <div className="stat-grid">
          <div className="stat">
            <div className="stat-label">Last</div>
            <div className="stat-value">{fmt.money(stats.lastPrice)}</div>
            <div className={"stat-sub " + (stats.dayChange >= 0 ? "" : "")} style={{ color: stats.dayChange >= 0 ? "var(--buy)" : "var(--sell)" }}>
              {stats.dayChange >= 0 ? "+" : ""}{stats.dayChange?.toFixed(2)}%
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Filings</div>
            <div className="stat-value">{stats.totalFilings}</div>
            <div className="stat-sub">{stats.insiders} insiders</div>
          </div>
          <div className="stat">
            <div className="stat-label">Buys / Sells</div>
            <div className="stat-value"><span className="buy">{stats.buys}</span> <span style={{ color: "var(--fg-faint)" }}>/</span> <span className="sell">{stats.sells}</span></div>
            <div className="stat-sub">{fmt.moneyBig(stats.buyValue)} / {fmt.moneyBig(stats.sellValue)}</div>
          </div>
          <div className="stat">
            <div className="stat-label">Net Insider</div>
            <div className={"stat-value " + (stats.netValue >= 0 ? "buy" : "sell")}>{stats.netValue >= 0 ? "+" : "−"}{fmt.moneyBig(Math.abs(stats.netValue))}</div>
            <div className="stat-sub">last 90 days</div>
          </div>
        </div>
      </div>

      <CandleChart
        ohlcv={filteredOhlcv}
        transactions={allTxns}
        period={period}
        setPeriod={setPeriod}
        showBuys={showBuys}
        showSells={showSells}
        setShowBuys={setShowBuys}
        setShowSells={setShowSells}
        themeMode={themeMode}
      />

      <div className="table-wrap" style={{ margin: "20px 24px", maxHeight: 520 }}>
        <div className="table-toolbar">
          <span>All filings for <b style={{ color: "var(--fg)" }}>{ticker}</b> · <b style={{ color: "var(--fg)" }}>{stats.totalFilings}</b> records</span>
          <span className="spacer" />
          <span>Sort: <b style={{ color: "var(--fg)" }}>{sort.key.replace(/_/g, " ")}</b> {sort.dir === "asc" ? "↑" : "↓"}</span>
        </div>
        <DataTable
          columns={columns}
          rows={paged}
          sort={sort}
          onSort={handleSort}
          page={page}
          pageSize={pageSize}
          total={sortedTxns.length}
          onPage={setPage}
          onPageSize={(n) => { setPageSize(n); setPage(1); }}
        />
      </div>
    </div>
  );
}

// ----------------------------- CHART -------------------------------------
function CandleChart({ ohlcv, transactions, period, setPeriod, showBuys, showSells, setShowBuys, setShowSells, themeMode }) {
  const containerRef = useRef(null);
  const chartRef = useRef(null);
  const seriesRef = useRef(null);
  const [hover, setHover] = useState(null);

  // Build the chart once container is mounted
  useLayoutEffect(() => {
    if (!containerRef.current || !window.LightweightCharts) return;
    const styles = getComputedStyle(document.documentElement);
    const isDark = themeMode === "dark";

    const chart = LightweightCharts.createChart(containerRef.current, {
      autoSize: true,
      layout: {
        background: { type: "solid", color: "transparent" },
        textColor: isDark ? "#9a9ea8" : "#61656f",
        fontFamily: "IBM Plex Mono, ui-monospace, monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: isDark ? "#1c1f2a" : "#eeeeea" },
        horzLines: { color: isDark ? "#1c1f2a" : "#eeeeea" },
      },
      rightPriceScale: {
        borderColor: isDark ? "#232634" : "#e4e4e0",
      },
      timeScale: {
        borderColor: isDark ? "#232634" : "#e4e4e0",
        timeVisible: false,
      },
      crosshair: {
        mode: 1,
        vertLine: { color: isDark ? "#3a3d4d" : "#9a9ea8", width: 1, style: 3, labelBackgroundColor: isDark ? "#181a25" : "#161726" },
        horzLine: { color: isDark ? "#3a3d4d" : "#9a9ea8", width: 1, style: 3, labelBackgroundColor: isDark ? "#181a25" : "#161726" },
      },
    });

    const series = chart.addCandlestickSeries({
      upColor: "#16a34a",
      downColor: "#dc2626",
      borderUpColor: "#16a34a",
      borderDownColor: "#dc2626",
      wickUpColor: "#16a34a",
      wickDownColor: "#dc2626",
    });

    chartRef.current = chart;
    seriesRef.current = series;

    chart.subscribeCrosshairMove((param) => {
      if (!param.time || !param.seriesData) { setHover(null); return; }
      const data = param.seriesData.get(series);
      if (!data) { setHover(null); return; }
      setHover({ time: param.time, ...data });
    });

    return () => { chart.remove(); chartRef.current = null; seriesRef.current = null; };
  }, [themeMode]);

  // Push data
  useEffect(() => {
    if (!seriesRef.current) return;
    seriesRef.current.setData(ohlcv.map((c) => ({ time: c.date, open: c.open, high: c.high, low: c.low, close: c.close })));

    // Markers
    const dateBuckets = {};
    transactions.forEach((t) => {
      if (!dateBuckets[t.transaction_date]) dateBuckets[t.transaction_date] = { buy: 0, sell: 0 };
      if (t.number_of_securities > 0) dateBuckets[t.transaction_date].buy++;
      else dateBuckets[t.transaction_date].sell++;
    });

    const dataDates = new Set(ohlcv.map((c) => c.date));
    const markers = [];
    Object.entries(dateBuckets).forEach(([date, b]) => {
      if (!dataDates.has(date)) return;
      if (showBuys && b.buy > 0) markers.push({ time: date, position: "belowBar", color: "#16a34a", shape: "arrowUp", text: "B" + (b.buy > 1 ? "·" + b.buy : "") });
      if (showSells && b.sell > 0) markers.push({ time: date, position: "aboveBar", color: "#dc2626", shape: "arrowDown", text: "S" + (b.sell > 1 ? "·" + b.sell : "") });
    });
    markers.sort((a, b) => a.time.localeCompare(b.time));
    seriesRef.current.setMarkers(markers);
    chartRef.current && chartRef.current.timeScale().fitContent();
  }, [ohlcv, transactions, showBuys, showSells]);

  const periods = ["1m", "3m", "6m", "1y", "2y"];

  return (
    <div className="chart-section">
      <div className="chart-toolbar">
        <div className="group">
          {periods.map((p) => (
            <button key={p} className={period === p ? "active" : ""} onClick={() => setPeriod(p)}>{p.toUpperCase()}</button>
          ))}
        </div>
        <label className="toggle" onClick={() => setShowBuys((v) => !v)}>
          <span style={{ color: showBuys ? "var(--buy)" : "var(--fg-faint)", fontFamily: "var(--font-mono)" }}>{showBuys ? "▲" : "△"}</span>
          <span style={{ color: showBuys ? "var(--fg)" : "var(--fg-faint)" }}>Buys</span>
        </label>
        <label className="toggle" onClick={() => setShowSells((v) => !v)}>
          <span style={{ color: showSells ? "var(--sell)" : "var(--fg-faint)", fontFamily: "var(--font-mono)" }}>{showSells ? "▼" : "▽"}</span>
          <span style={{ color: showSells ? "var(--fg)" : "var(--fg-faint)" }}>Sells</span>
        </label>
        <span className="spacer" />
        {hover && (
          <div className="hover-info">
            <span><span className="label">D</span> <b>{hover.time}</b></span>
            <span><span className="label">O</span> <b>{hover.open?.toFixed(2)}</b></span>
            <span><span className="label">H</span> <b>{hover.high?.toFixed(2)}</b></span>
            <span><span className="label">L</span> <b>{hover.low?.toFixed(2)}</b></span>
            <span><span className="label">C</span> <b className={hover.close >= hover.open ? "pos" : "neg"}>{hover.close?.toFixed(2)}</b></span>
          </div>
        )}
      </div>
      <div className="chart-container" ref={containerRef} />
    </div>
  );
}

Object.assign(window, { TickerView });
