/* global React, ReactDOM, Dashboard, TickerView, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor */
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "compact",
  "dark": false,
  "accent": "#2A6FDB",
  "monoNumerics": true
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = useState({ view: "dashboard", ticker: null });
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(id);
  }, []);

  // Apply tweak effects globally
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", t.dark ? "dark" : "light");
    document.documentElement.setAttribute("data-density", t.density);
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.dark, t.density, t.accent]);

  const navTo = (view, ticker = null) => {
    setRoute({ view, ticker });
    document.querySelector(".app-main")?.scrollTo?.(0, 0);
  };

  return (
    <>
      <header className="app-header">
        <div className="brand">
          <div className="brand-mark">S</div>
          <div>
            <div className="brand-name">SEDI Dashboard</div>
          </div>
          <span className="brand-sub">v1.0</span>
        </div>
        <nav className="tabs">
          <button
            className={"tab" + (route.view === "dashboard" ? " active" : "")}
            onClick={() => navTo("dashboard")}
          >Transactions</button>
          <button
            className={"tab" + (route.view === "market" ? " active" : "")}
            onClick={() => navTo("market")}
          >Market</button>
          <button
            className={"tab" + (route.view === "ticker" ? " active" : "")}
            onClick={() => route.ticker && navTo("ticker", route.ticker)}
            style={{ opacity: route.ticker ? 1 : 0.5, pointerEvents: route.ticker ? "auto" : "none" }}
          >
            {route.ticker ? <>Ticker <span style={{ fontFamily: "var(--font-mono)", marginLeft: 4 }}>{route.ticker}</span></> : "Ticker"}
          </button>
        </nav>
        <div className="header-spacer" />
        <div className="header-meta">
          <span><span className="dot" />enrichment online</span>
          <span>api v1</span>
          <span>{now.toLocaleString("en-CA", { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", timeZoneName: "short" })}</span>
        </div>
      </header>

      <main className="app-main">
        {route.view === "dashboard" && (
          <Dashboard onOpenTicker={(ticker) => navTo("ticker", ticker)} />
        )}
        {route.view === "market" && (
          <MarketView onOpenTicker={(ticker) => navTo("ticker", ticker)} />
        )}
        {route.view === "ticker" && route.ticker && (
          <TickerView
            key={route.ticker}
            ticker={route.ticker}
            onBack={() => navTo("dashboard")}
            onOpenTicker={(ticker) => navTo("ticker", ticker)}
            themeMode={t.dark ? "dark" : "light"}
            accent={t.accent}
          />
        )}
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Appearance" />
        <TweakToggle label="Dark mode" value={t.dark} onChange={(v) => setTweak("dark", v)} />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["compact", "default", "comfortable"]}
          onChange={(v) => setTweak("density", v)}
        />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={["#2A6FDB", "#7A5AE0", "#16a34a", "#D97757"]}
          onChange={(v) => setTweak("accent", v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
