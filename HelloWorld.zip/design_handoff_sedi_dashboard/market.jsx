/* global React, MARKET_DATA, fmt, Icon */
const { useState, useMemo, useEffect, useRef } = React;

function MarketView({ onOpenTicker }) {
  const [moverTab, setMoverTab] = useState("gainers"); // gainers | losers | active
  const [sectorMetric, setSectorMetric] = useState("day"); // day | week | month | ytd

  return (
    <div className="view market-view">
      <div className="view-header">
        <div>
          <h1 className="view-title">Canadian Market Overview</h1>
          <div className="view-subtitle">TSX · indices, sectors, movers · cross-referenced with insider activity</div>
        </div>
        <div className="market-asof">
          <span className="pulse" />
          As of {MARKET_DATA.asOf}
        </div>
      </div>

      <div style={{ padding: "0 0 16px" }}>
        {/* Index strip */}
        <div className="idx-strip">
          {MARKET_DATA.INDICES.map((idx) => <IndexTile key={idx.symbol} idx={idx} />)}
        </div>

        <div className="market-grid">
          {/* LEFT: sector heatmap + insider sentiment */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <SectorHeatmap metric={sectorMetric} setMetric={setSectorMetric} />
            <InsiderSentimentPanel onOpenTicker={onOpenTicker} />
          </div>

          {/* RIGHT: movers */}
          <MoversPanel tab={moverTab} setTab={setMoverTab} onOpenTicker={onOpenTicker} />
        </div>
      </div>
    </div>
  );
}

// ----- Index tile with sparkline -----
function IndexTile({ idx }) {
  const positive = idx.change >= 0;
  const spark = idx.spark;
  const min = Math.min(...spark);
  const max = Math.max(...spark);
  const W = 70, H = 32;
  const points = spark.map((v, i) => {
    const x = (i / (spark.length - 1)) * W;
    const y = H - ((v - min) / (max - min || 1)) * H;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");

  const fmtVal = (v) => {
    if (idx.symbol === "USDCAD=X") return v.toFixed(4);
    if (idx.symbol === "CL=F") return v.toFixed(2);
    return new Intl.NumberFormat("en-CA", { maximumFractionDigits: 2 }).format(v);
  };
  const delta = idx.last - idx.prev;

  return (
    <div className="idx-tile">
      <div className="symbol">{idx.symbol}</div>
      <div className="name">{idx.name}</div>
      <div className="last">{fmtVal(idx.last)}</div>
      <div className={"chg " + (positive ? "pos" : "neg")}>
        <span>{positive ? "▲" : "▼"}</span>
        <span>{positive ? "+" : ""}{fmtVal(Math.abs(delta))}</span>
        <span>({positive ? "+" : ""}{idx.change.toFixed(2)}%)</span>
      </div>
      <svg className="spark" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        <polyline
          points={points}
          fill="none"
          stroke={positive ? "var(--buy)" : "var(--sell)"}
          strokeWidth="1.5"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}

// ----- Sector heatmap -----
function SectorHeatmap({ metric, setMetric }) {
  const sectors = MARKET_DATA.SECTORS;
  const maxAbs = Math.max(...sectors.map((s) => Math.abs(s[metric])));

  // Lay out as treemap-ish strips weighted by sector weight.
  // Two rows; first row holds the 5 biggest sectors, second row holds the rest.
  const sorted = [...sectors].sort((a, b) => b.weight - a.weight);
  const top = sorted.slice(0, 5);
  const bot = sorted.slice(5);

  const colFor = (cells, totalCols = 12) => {
    const total = cells.reduce((a, b) => a + b.weight, 0);
    let cols = cells.map((c) => Math.max(1, Math.round((c.weight / total) * totalCols)));
    let diff = totalCols - cols.reduce((a, b) => a + b, 0);
    while (diff !== 0) {
      const i = diff > 0 ? cols.indexOf(Math.min(...cols)) : cols.indexOf(Math.max(...cols));
      cols[i] += diff > 0 ? 1 : -1;
      diff += diff > 0 ? -1 : 1;
    }
    return cols;
  };
  const topCols = colFor(top);
  const botCols = colFor(bot);

  const cellFor = (s, span) => {
    const v = s[metric];
    const intensity = Math.min(1, Math.abs(v) / maxAbs);
    const isPos = v >= 0;
    const bg = isPos
      ? `oklch(${68 - intensity * 18}% ${0.04 + intensity * 0.14} 148)`
      : `oklch(${68 - intensity * 18}% ${0.04 + intensity * 0.17} 28)`;
    const fg = intensity > 0.35 ? "#fff" : "var(--fg)";
    const sw = intensity > 0.35 ? "rgba(255,255,255,0.7)" : "var(--fg-muted)";
    return (
      <div
        key={s.name}
        className="sector-cell"
        style={{ background: bg, color: fg, gridColumn: `span ${span}` }}
        title={`${s.name} · ${v >= 0 ? "+" : ""}${v.toFixed(2)}% (${metric})`}
      >
        <span className="sn">{s.name}</span>
        <div className="row">
          <span className="sv">{v >= 0 ? "+" : ""}{v.toFixed(2)}%</span>
          <span className="sw" style={{ color: sw }}>· {s.weight.toFixed(1)}%</span>
        </div>
      </div>
    );
  };

  const metrics = [
    { k: "day", label: "1D" },
    { k: "week", label: "1W" },
    { k: "month", label: "1M" },
    { k: "ytd", label: "YTD" },
  ];

  return (
    <div className="market-panel">
      <div className="panel-head">
        TSX Sector Performance
        <span className="spacer" />
        <div className="seg">
          {metrics.map((m) => (
            <button key={m.k} className={metric === m.k ? "active" : ""} onClick={() => setMetric(m.k)}>{m.label}</button>
          ))}
        </div>
      </div>
      <div className="sector-map">
        {top.map((s, i) => cellFor(s, topCols[i]))}
        {bot.map((s, i) => cellFor(s, botCols[i]))}
      </div>
    </div>
  );
}

// ----- Insider sentiment (built from existing SEDI transactions) -----
function InsiderSentimentPanel({ onOpenTicker }) {
  const sentiment = useMemo(() => MARKET_DATA.sentiment, []);

  const totals = useMemo(() => {
    let buys = 0, sells = 0, buyValue = 0, sellValue = 0;
    sentiment.forEach((d) => {
      buys += d.buys;
      sells += d.sells;
      buyValue += d.buyValue;
      sellValue += d.sellValue;
    });
    const ratio = sells === 0 ? Infinity : buys / sells;
    const net = buyValue - sellValue;
    return { buys, sells, ratio, net };
  }, [sentiment]);

  // Build line + bar chart manually in SVG for full control.
  // X: dates; Y top half: cumulative net value; Y bottom half: daily buy/sell bars.
  const W = 880, H = 200, padL = 40, padR = 12, padT = 12, padB = 22;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;
  const splitY = padT + innerH * 0.55;

  const dates = sentiment.map((d) => d.date);
  const minDate = dates[0];
  const maxDate = dates[dates.length - 1];
  const minT = new Date(minDate).getTime();
  const maxT = new Date(maxDate).getTime();
  const xFor = (d) => padL + ((new Date(d).getTime() - minT) / (maxT - minT || 1)) * innerW;

  // Cumulative net value
  let cum = 0;
  const cumPoints = sentiment.map((d) => {
    cum += (d.buyValue - d.sellValue);
    return { date: d.date, cum };
  });
  const cumMax = Math.max(...cumPoints.map((p) => p.cum));
  const cumMin = Math.min(...cumPoints.map((p) => p.cum));
  const cumRange = (cumMax - cumMin) || 1;
  const yForCum = (v) => padT + (1 - (v - cumMin) / cumRange) * (splitY - padT - 6);

  const linePath = cumPoints.map((p, i) => `${i === 0 ? "M" : "L"} ${xFor(p.date).toFixed(1)} ${yForCum(p.cum).toFixed(1)}`).join(" ");
  const areaPath = linePath + ` L ${xFor(cumPoints[cumPoints.length - 1].date).toFixed(1)} ${splitY.toFixed(1)} L ${xFor(cumPoints[0].date).toFixed(1)} ${splitY.toFixed(1)} Z`;

  // Daily bars (bottom half)
  const maxDaily = Math.max(...sentiment.map((d) => Math.max(d.buys, d.sells)));
  const barH = (n) => (n / maxDaily) * (H - padB - splitY - 4);
  const barW = Math.max(1, Math.min(8, innerW / sentiment.length - 1));

  // X axis ticks (monthly)
  const monthTicks = [];
  const seen = new Set();
  dates.forEach((d) => {
    const m = d.slice(0, 7);
    if (!seen.has(m)) { seen.add(m); monthTicks.push(d); }
  });

  const [hover, setHover] = useState(null);
  const svgRef = useRef(null);

  const handleMove = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * W;
    if (px < padL || px > W - padR) { setHover(null); return; }
    const t = minT + ((px - padL) / innerW) * (maxT - minT);
    let best = null, bestDist = Infinity;
    sentiment.forEach((s) => {
      const dist = Math.abs(new Date(s.date).getTime() - t);
      if (dist < bestDist) { bestDist = dist; best = s; }
    });
    if (best) {
      const c = cumPoints.find((p) => p.date === best.date);
      setHover({ ...best, cum: c?.cum });
    }
  };

  return (
    <div className="market-panel">
      <div className="panel-head">
        Aggregate Insider Sentiment — TSX
        <span className="spacer" />
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, textTransform: "none", letterSpacing: 0, color: "var(--fg-muted)" }}>
          <span style={{ display: "inline-block", width: 10, height: 2, background: "var(--buy)", verticalAlign: "middle", marginRight: 5 }} />
          cum. net value
          <span style={{ display: "inline-block", width: 8, height: 8, background: "var(--buy)", verticalAlign: "middle", margin: "0 5px 0 12px" }} />
          buys
          <span style={{ display: "inline-block", width: 8, height: 8, background: "var(--sell)", verticalAlign: "middle", margin: "0 5px 0 8px" }} />
          sells
        </span>
      </div>
      <div className="sentiment-stats">
        <div className="item">
          <div className="l">Acquisitions</div>
          <div className="v pos">{totals.buys.toLocaleString()}</div>
          <div className="sub">{totals.ratio === Infinity ? "—" : "vs " + totals.sells + " disp."}</div>
        </div>
        <div className="item">
          <div className="l">Buy / Sell ratio</div>
          <div className="v">{totals.ratio === Infinity ? "∞" : totals.ratio.toFixed(2)}</div>
          <div className="sub">{totals.ratio >= 1 ? "Net bullish" : "Net bearish"}</div>
        </div>
        <div className="item">
          <div className="l">Net insider $</div>
          <div className={"v " + (totals.net >= 0 ? "pos" : "neg")}>
            {totals.net >= 0 ? "+" : "−"}{fmt.moneyBig(Math.abs(totals.net))}
          </div>
          <div className="sub">across 14 issuers</div>
        </div>
      </div>
      <div className="sentiment-chart" style={{ position: "relative" }}>
        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          preserveAspectRatio="none"
          style={{ width: "100%", height: "100%", display: "block" }}
          onMouseMove={handleMove}
          onMouseLeave={() => setHover(null)}
        >
          {/* zero line for cumulative */}
          {cumMin < 0 && cumMax > 0 && (
            <line x1={padL} x2={W - padR} y1={yForCum(0)} y2={yForCum(0)} stroke="var(--border)" strokeDasharray="3,3" />
          )}

          {/* x grid (month ticks) */}
          {monthTicks.map((d) => (
            <line key={d} x1={xFor(d)} x2={xFor(d)} y1={padT} y2={H - padB} stroke="var(--border)" opacity="0.4" />
          ))}

          {/* cumulative area + line */}
          <path d={areaPath} fill="var(--buy)" opacity="0.10" />
          <path d={linePath} fill="none" stroke="var(--buy)" strokeWidth="1.5" />

          {/* daily bars: buys up from split, sells down from split */}
          {sentiment.map((d) => {
            const x = xFor(d.date) - barW / 2;
            return (
              <g key={d.date}>
                {d.buys > 0 && (
                  <rect x={x} y={splitY - 1} width={barW} height={Math.max(1, barH(d.buys))} fill="var(--buy)" opacity="0.85" />
                )}
                {d.sells > 0 && (
                  <rect x={x + barW + 0.5} y={splitY - 1} width={barW} height={Math.max(1, barH(d.sells))} fill="var(--sell)" opacity="0.85" />
                )}
              </g>
            );
          })}

          {/* split line */}
          <line x1={padL} x2={W - padR} y1={splitY} y2={splitY} stroke="var(--border-strong)" />

          {/* y axis labels */}
          <text x={padL - 6} y={padT + 8} textAnchor="end" fontSize="9" fill="var(--fg-faint)" fontFamily="var(--font-mono)">{fmt.moneyBig(cumMax)}</text>
          <text x={padL - 6} y={splitY - 4} textAnchor="end" fontSize="9" fill="var(--fg-faint)" fontFamily="var(--font-mono)">{cumMin < 0 ? fmt.moneyBig(cumMin) : "$0"}</text>
          <text x={padL - 6} y={splitY + 12} textAnchor="end" fontSize="9" fill="var(--fg-faint)" fontFamily="var(--font-mono)">0</text>
          <text x={padL - 6} y={H - padB - 2} textAnchor="end" fontSize="9" fill="var(--fg-faint)" fontFamily="var(--font-mono)">{maxDaily}</text>

          {/* x axis labels */}
          {monthTicks.map((d) => (
            <text key={d} x={xFor(d)} y={H - 6} fontSize="9.5" fill="var(--fg-muted)" fontFamily="var(--font-mono)" textAnchor="middle">
              {new Date(d + "T12:00:00").toLocaleDateString("en-CA", { month: "short" })}
            </text>
          ))}

          {/* hover cursor */}
          {hover && (
            <line x1={xFor(hover.date)} x2={xFor(hover.date)} y1={padT} y2={H - padB} stroke="var(--fg-muted)" strokeDasharray="2,3" />
          )}
        </svg>
        {hover && (
          <div
            className="chart-tooltip"
            style={{
              left: `min(${(xFor(hover.date) / W) * 100}%, calc(100% - 200px))`,
              top: 12,
              transform: "translateX(8px)",
            }}
          >
            <div><span className="label">date</span> {hover.date}</div>
            <div className="sep" />
            <div><span className="label">buys </span><span className="buy">{hover.buys}</span> <span className="label">· </span>{fmt.moneyBig(hover.buyValue)}</div>
            <div><span className="label">sells</span> <span className="sell">{hover.sells}</span> <span className="label">· </span>{fmt.moneyBig(hover.sellValue)}</div>
            <div className="sep" />
            <div><span className="label">cum. net</span> <b style={{ color: hover.cum >= 0 ? "oklch(75% 0.16 148)" : "oklch(72% 0.18 28)" }}>{hover.cum >= 0 ? "+" : "−"}{fmt.moneyBig(Math.abs(hover.cum))}</b></div>
          </div>
        )}
      </div>
    </div>
  );
}

// ----- Movers panel with tabs -----
function MoversPanel({ tab, setTab, onOpenTicker }) {
  const list = tab === "gainers" ? MARKET_DATA.GAINERS : tab === "losers" ? MARKET_DATA.LOSERS : MARKET_DATA.MOST_ACTIVE;
  const showVol = tab === "active";

  // determine which tickers in this list also appear in SEDI
  const sediTickers = new Set((window.MOCK_DATA?.TRANSACTIONS || []).map((t) => t.issuer_ticker));

  return (
    <div className="market-panel" style={{ alignSelf: "start" }}>
      <div className="movers-tabs">
        <button className={tab === "gainers" ? "active" : ""} onClick={() => setTab("gainers")}>Top Gainers</button>
        <button className={tab === "losers" ? "active" : ""} onClick={() => setTab("losers")}>Top Losers</button>
        <button className={tab === "active" ? "active" : ""} onClick={() => setTab("active")}>Most Active</button>
      </div>
      <div className="mover-list">
        {list.map((m) => {
          const positive = m.chg >= 0;
          const inSedi = sediTickers.has(m.ticker);
          return (
            <div
              key={m.ticker}
              className="mover-row"
              onClick={() => inSedi && onOpenTicker(m.ticker)}
              style={inSedi ? null : { cursor: "default", opacity: 0.95 }}
              title={inSedi ? "Open in SEDI dashboard" : "No SEDI filings in dataset"}
            >
              <span className="mt">{m.ticker}</span>
              <span className="mn">{m.name}{inSedi && <span style={{ marginLeft: 6, color: "var(--accent)", fontSize: 10 }}>● SEDI</span>}</span>
              <span className="mp">{showVol ? (m.vol / 1e6).toFixed(1) + "M" : "$" + m.last.toFixed(2)}</span>
              <span className={"mc " + (positive ? "pos" : "neg")}>
                {positive ? "+" : ""}{m.chg.toFixed(2)}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { MarketView });
