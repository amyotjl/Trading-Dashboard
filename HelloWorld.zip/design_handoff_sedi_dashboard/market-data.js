/* Market mock data — modeled after what yfinance / TradingView would return.
   In the real impl: Rails proxies these through the Python enrichment service.
*/

(function () {
  function rngSeeded(seed) {
    return function () {
      let t = (seed += 0x6d2b79f5);
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rng = rngSeeded(42);

  // ---- Index tiles ----
  const INDICES = [
    { symbol: "^GSPTSE", name: "S&P/TSX Composite",      base: 24850, change: 0.31,  vol: "—" },
    { symbol: "^TX60",   name: "S&P/TSX 60",             base: 1492,  change: 0.24,  vol: "—" },
    { symbol: "^GSPC",   name: "S&P 500",                base: 5870,  change: -0.18, vol: "—" },
    { symbol: "USDCAD=X",name: "USD / CAD",              base: 1.367, change: 0.12,  vol: "—" },
    { symbol: "CL=F",    name: "WTI Crude Oil",          base: 71.42, change: -0.92, vol: "—" },
    { symbol: "GC=F",    name: "Gold (Spot)",            base: 2645,  change: 0.48,  vol: "—" },
  ];

  // Generate a 30-point sparkline for each index trending toward the close
  INDICES.forEach((idx) => {
    const points = 30;
    const series = [];
    let v = idx.base * (1 - idx.change / 100) * (0.985 + rng() * 0.03);
    const target = idx.base;
    for (let i = 0; i < points; i++) {
      const drift = (target - v) * (i / points) * 0.15;
      const noise = (rng() - 0.5) * idx.base * 0.004;
      v += drift + noise;
      series.push(+v.toFixed(4));
    }
    series[series.length - 1] = idx.base;
    idx.last = idx.base;
    idx.prev = +(idx.base * (1 - idx.change / 100)).toFixed(4);
    idx.spark = series;
  });

  // ---- TSX sectors ----
  // 11 GICS sectors. % chg is daily; weighted approximation.
  const SECTORS = [
    { name: "Financials",          weight: 30.4, day: 0.42, week: 1.18, month: 2.95, ytd: 9.8 },
    { name: "Energy",              weight: 17.2, day: -0.86, week: -2.34, month: 1.05, ytd: 4.3 },
    { name: "Materials",           weight: 11.8, day: 1.12, week: 2.81, month: 5.42, ytd: 12.4 },
    { name: "Industrials",         weight: 13.6, day: 0.18, week: 0.42, month: -0.85, ytd: 6.1 },
    { name: "Technology",          weight: 9.4,  day: -0.95, week: -1.62, month: 4.31, ytd: 18.7 },
    { name: "Communication",       weight: 3.1,  day: -0.27, week: 0.55, month: -2.14, ytd: -8.2 },
    { name: "Consumer Discretionary",weight: 3.8,day: 0.65, week: 1.92, month: 3.24, ytd: 7.5 },
    { name: "Consumer Staples",    weight: 4.2,  day: 0.31, week: 0.74, month: 1.85, ytd: 3.9 },
    { name: "Utilities",           weight: 3.5,  day: -0.14, week: -0.62, month: 2.41, ytd: 1.2 },
    { name: "Real Estate",         weight: 2.4,  day: 0.52, week: 1.04, month: 2.18, ytd: -1.4 },
    { name: "Health Care",         weight: 0.6,  day: -1.84, week: -3.21, month: -5.42, ytd: -14.6 },
  ];

  // ---- Movers (top gainers, losers, most active on TSX) ----
  const GAINERS = [
    { ticker: "WEED.TO",  name: "Canopy Growth Corp",         last: 4.87,   chg: 12.41, vol: 8.4e6 },
    { ticker: "AC.TO",    name: "Air Canada",                 last: 22.34,  chg: 6.85,  vol: 5.2e6 },
    { ticker: "BB.TO",    name: "BlackBerry Ltd",             last: 4.21,   chg: 5.92,  vol: 9.1e6 },
    { ticker: "ABX.TO",   name: "Barrick Gold Corp",          last: 22.14,  chg: 4.18,  vol: 6.8e6 },
    { ticker: "SHOP.TO",  name: "Shopify Inc",                last: 142.61, chg: 3.74,  vol: 3.5e6 },
    { ticker: "K.TO",     name: "Kinross Gold Corp",          last: 14.82,  chg: 3.51,  vol: 4.9e6 },
  ];
  const LOSERS = [
    { ticker: "BCE.TO",   name: "BCE Inc",                    last: 33.94,  chg: -4.62, vol: 5.7e6 },
    { ticker: "T.TO",     name: "Telus Corp",                 last: 19.85,  chg: -3.21, vol: 4.2e6 },
    { ticker: "CNQ.TO",   name: "Canadian Natural Resources", last: 47.92,  chg: -2.84, vol: 3.8e6 },
    { ticker: "SU.TO",    name: "Suncor Energy",              last: 49.18,  chg: -2.31, vol: 4.5e6 },
    { ticker: "CVE.TO",   name: "Cenovus Energy",             last: 21.06,  chg: -1.95, vol: 6.1e6 },
    { ticker: "ENB.TO",   name: "Enbridge Inc",               last: 56.42,  chg: -1.42, vol: 5.3e6 },
  ];
  const MOST_ACTIVE = [
    { ticker: "TD.TO",    name: "Toronto-Dominion Bank",      last: 82.07,  chg: 0.11,  vol: 12.4e6 },
    { ticker: "RY.TO",    name: "Royal Bank of Canada",       last: 168.43, chg: 0.32,  vol: 9.8e6 },
    { ticker: "BNS.TO",   name: "Bank of Nova Scotia",        last: 71.20,  chg: -0.22, vol: 8.9e6 },
    { ticker: "MFC.TO",   name: "Manulife Financial",         last: 44.83,  chg: 0.78,  vol: 8.1e6 },
    { ticker: "ENB.TO",   name: "Enbridge Inc",               last: 56.42,  chg: -1.42, vol: 7.9e6 },
    { ticker: "CNR.TO",   name: "Canadian National Railway",  last: 152.88, chg: 0.45,  vol: 5.6e6 },
  ];

  // ---- Aggregate insider sentiment (built off existing SEDI transactions) ----
  function buildSentiment() {
    if (!window.MOCK_DATA) return [];
    const byDate = {};
    window.MOCK_DATA.TRANSACTIONS.forEach((t) => {
      const d = t.transaction_date;
      if (!byDate[d]) byDate[d] = { date: d, buys: 0, sells: 0, buyValue: 0, sellValue: 0 };
      if (t.number_of_securities > 0) {
        byDate[d].buys++;
        byDate[d].buyValue += Math.abs(t.number_of_securities) * (t.unit_price || 0);
      } else {
        byDate[d].sells++;
        byDate[d].sellValue += Math.abs(t.number_of_securities) * (t.unit_price || 0);
      }
    });
    return Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date));
  }

  Object.assign(window, {
    MARKET_DATA: {
      INDICES,
      SECTORS,
      GAINERS,
      LOSERS,
      MOST_ACTIVE,
      get sentiment() { return buildSentiment(); },
      asOf: "Mar 28, 2025 · 16:00 EDT",
    },
  });
})();
