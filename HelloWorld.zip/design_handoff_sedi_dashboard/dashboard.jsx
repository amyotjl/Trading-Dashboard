/* global React, MOCK_DATA, fmt, Select, DataTable, Field, Icon */
const { useState, useMemo, useEffect } = React;

function Dashboard({ onOpenTicker }) {
  const all = MOCK_DATA.TRANSACTIONS;

  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    ticker: "",
    insider: "",
    natureId: null,
    minInsiders: "",
  });
  const [sort, setSort] = useState({ key: "filing_date", dir: "desc" });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const setF = (k, v) => { setFilters((p) => ({ ...p, [k]: v })); setPage(1); };
  const clearFilters = () => {
    setFilters({ dateFrom: "", dateTo: "", ticker: "", insider: "", natureId: null, minInsiders: "" });
    setPage(1);
  };

  // --- filter
  const filtered = useMemo(() => {
    let rows = all;
    if (filters.dateFrom) rows = rows.filter((r) => r.transaction_date >= filters.dateFrom);
    if (filters.dateTo) rows = rows.filter((r) => r.transaction_date <= filters.dateTo);
    if (filters.ticker.trim()) {
      const q = filters.ticker.trim().toUpperCase();
      rows = rows.filter((r) => r.issuer_ticker.toUpperCase().includes(q));
    }
    if (filters.insider.trim()) {
      const q = filters.insider.trim().toLowerCase();
      rows = rows.filter((r) => r.insider_name.toLowerCase().includes(q));
    }
    if (filters.natureId) {
      rows = rows.filter((r) => r.nature_of_transaction.code === filters.natureId);
    }
    if (filters.minInsiders) {
      const min = parseInt(filters.minInsiders, 10);
      if (!isNaN(min) && min > 1) {
        const map = {};
        all.forEach((r) => {
          if (!map[r.issuer_ticker]) map[r.issuer_ticker] = new Set();
          map[r.issuer_ticker].add(r.insider_name);
        });
        const allowed = new Set(Object.keys(map).filter((t) => map[t].size >= min));
        rows = rows.filter((r) => allowed.has(r.issuer_ticker));
      }
    }
    return rows;
  }, [all, filters]);

  // --- sort
  const sorted = useMemo(() => {
    const out = [...filtered];
    const { key, dir } = sort;
    out.sort((a, b) => {
      let av, bv;
      switch (key) {
        case "filing_date": case "transaction_date":
          av = a[key]; bv = b[key]; break;
        case "insider_name": case "issuer_ticker": case "security_designation":
          av = a[key]; bv = b[key]; break;
        case "nature": av = a.nature_of_transaction.code; bv = b.nature_of_transaction.code; break;
        case "shares": av = a.number_of_securities; bv = b.number_of_securities; break;
        case "price": av = a.unit_price ?? 0; bv = b.unit_price ?? 0; break;
        case "balance": av = a.balance; bv = b.balance; break;
        default: av = a[key]; bv = b[key];
      }
      if (av < bv) return dir === "asc" ? -1 : 1;
      if (av > bv) return dir === "asc" ? 1 : -1;
      return 0;
    });
    return out;
  }, [filtered, sort]);

  const total = sorted.length;
  const paged = useMemo(() => {
    const start = (page - 1) * pageSize;
    return sorted.slice(start, start + pageSize);
  }, [sorted, page, pageSize]);

  const handleSort = (key) => {
    setSort((s) => s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "desc" });
  };

  // --- KPIs
  const kpi = useMemo(() => {
    const buys = filtered.filter((r) => r.number_of_securities > 0);
    const sells = filtered.filter((r) => r.number_of_securities < 0);
    const sumValue = (rs) => rs.reduce((acc, r) => acc + Math.abs(r.number_of_securities) * (r.unit_price || 0), 0);
    const uniqueIssuers = new Set(filtered.map((r) => r.issuer_ticker)).size;
    const uniqueInsiders = new Set(filtered.map((r) => r.insider_name)).size;
    return {
      total: filtered.length,
      buys: buys.length,
      sells: sells.length,
      buyValue: sumValue(buys),
      sellValue: sumValue(sells),
      issuers: uniqueIssuers,
      insiders: uniqueInsiders,
    };
  }, [filtered]);

  // --- Sector heatmap (size by # of filings, color by buy/sell net value)
  const heatmap = useMemo(() => {
    const byTicker = {};
    filtered.forEach((r) => {
      if (!byTicker[r.issuer_ticker]) byTicker[r.issuer_ticker] = { ticker: r.issuer_ticker, name: r.issuer_name, sector: "", net: 0, count: 0 };
      byTicker[r.issuer_ticker].count++;
      byTicker[r.issuer_ticker].net += r.number_of_securities * (r.unit_price || 0);
    });
    Object.values(byTicker).forEach((t) => {
      const iss = MOCK_DATA.ISSUERS.find((i) => i.ticker === t.ticker);
      t.sector = iss ? iss.sector : "—";
    });
    return Object.values(byTicker).sort((a, b) => b.count - a.count).slice(0, 12);
  }, [filtered]);

  // --- Insider leaderboard (most active)
  const leaderboard = useMemo(() => {
    const map = {};
    filtered.forEach((r) => {
      if (!map[r.insider_name]) map[r.insider_name] = { name: r.insider_name, buys: 0, sells: 0, tickers: new Set() };
      if (r.number_of_securities > 0) map[r.insider_name].buys++;
      else map[r.insider_name].sells++;
      map[r.insider_name].tickers.add(r.issuer_ticker);
    });
    return Object.values(map)
      .map((m) => ({ ...m, total: m.buys + m.sells, tickerCount: m.tickers.size }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 8);
  }, [filtered]);

  const natureOptions = MOCK_DATA.NATURE_OF_TXN.map((n) => ({ value: n.code, label: n.description, code: n.code }));

  const columns = [
    { key: "filing_date", label: "Filed", width: 92, render: (r) => <span className="mono">{fmt.dateShort(r.filing_date)}</span> },
    { key: "transaction_date", label: "Txn Date", width: 92, render: (r) => <span className="mono">{fmt.dateShort(r.transaction_date)}</span> },
    { key: "insider_name", label: "Insider", render: (r) => <span>{r.insider_name}</span> },
    { key: "relationships", label: "Relationship", sortable: false, render: (r) => (
      <span className="rel-cell">
        {r.relationships[0].replace(/^\d+\s*-\s*/, "")}
        {r.relationships.length > 1 && <span className="more">+{r.relationships.length - 1}</span>}
      </span>
    )},
    { key: "issuer_ticker", label: "Ticker", width: 100, render: (r) => (
      <a
        className="ticker-link"
        onClick={(e) => { e.stopPropagation(); onOpenTicker(r.issuer_ticker); }}
      >{r.issuer_ticker}</a>
    )},
    { key: "issuer_name", label: "Issuer", sortable: false, render: (r) => <span style={{ color: "var(--fg-muted)" }}>{r.issuer_name}</span> },
    { key: "security_designation", label: "Security", render: (r) => <span style={{ color: "var(--fg-muted)" }}>{r.security_designation}</span> },
    { key: "nature", label: "Txn Type", render: (r) => (
      <div className="txn-type-cell">
        <span className="code">{r.nature_of_transaction.code}</span>
        <span className="desc">{r.nature_of_transaction.description}</span>
      </div>
    )},
    { key: "shares", label: "Shares", numeric: true, render: (r) => (
      <span className={"shares-cell " + (r.number_of_securities > 0 ? "shares-pos" : "shares-neg")}>
        <span className="ind">{r.number_of_securities > 0 ? "▲" : "▼"}</span>
        {fmt.signed(r.number_of_securities)}
      </span>
    )},
    { key: "price", label: "Price", numeric: true, render: (r) => fmt.money(r.unit_price) },
    { key: "balance", label: "Balance", numeric: true, render: (r) => fmt.int(r.balance) },
  ];

  const activeFilters = Object.entries(filters).filter(([k, v]) => v !== "" && v != null);

  return (
    <div className="view">
      <div className="view-header">
        <div>
          <h1 className="view-title">Canadian Insider Transactions</h1>
          <div className="view-subtitle">SEDI · Q1 2025 dataset · sedi_2025_01_1.csv · 420 filings</div>
        </div>
        <div className="view-meta">
          <span><b>{kpi.issuers}</b> issuers</span>
          <span><b>{kpi.insiders}</b> insiders</span>
          <span><b>{kpi.total.toLocaleString()}</b> filings</span>
        </div>
      </div>

      {/* Stats strip */}
      <div className="stats-strip">
        {/* KPI panel */}
        <div className="panel">
          <div className="panel-header">Filings Summary</div>
          <div className="kpi-stack">
            <div className="kpi-row">
              <span className="l">Acquisitions</span>
              <span className="v pos">{kpi.buys.toLocaleString()}</span>
            </div>
            <div className="kpi-row" style={{ marginTop: -4 }}>
              <span className="l" style={{ visibility: "hidden" }}>x</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-muted)" }}>{fmt.moneyBig(kpi.buyValue)}</span>
            </div>
            <div className="kpi-divider" />
            <div className="kpi-row">
              <span className="l">Dispositions</span>
              <span className="v neg">{kpi.sells.toLocaleString()}</span>
            </div>
            <div className="kpi-row" style={{ marginTop: -4 }}>
              <span className="l" style={{ visibility: "hidden" }}>x</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-muted)" }}>{fmt.moneyBig(kpi.sellValue)}</span>
            </div>
            <div className="kpi-divider" />
            <div className="kpi-row">
              <span className="l">Buy / Sell ratio</span>
              <span className="v">{kpi.sells === 0 ? "∞" : (kpi.buys / kpi.sells).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Sector heatmap */}
        <div className="panel">
          <div className="panel-header">
            Issuer Activity — by Filing Volume
            <span className="spacer" />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--fg-faint)", textTransform: "none", letterSpacing: 0 }}>
              <span style={{ display: "inline-block", width: 8, height: 8, background: "var(--buy)", borderRadius: 1, verticalAlign: "middle", marginRight: 4 }} />net buying
              <span style={{ display: "inline-block", width: 8, height: 8, background: "var(--sell)", borderRadius: 1, verticalAlign: "middle", margin: "0 4px 0 8px" }} />net selling
            </span>
          </div>
          <div className="panel-body tight">
            <Heatmap items={heatmap} onSelect={(t) => onOpenTicker(t)} />
          </div>
        </div>

        {/* Insider leaderboard */}
        <div className="panel">
          <div className="panel-header">Most Active Insiders <span className="spacer" /><span className="count">Top 8</span></div>
          <div className="panel-body tight">
            <div className="leaderboard">
              {leaderboard.map((lb, i) => {
                const max = leaderboard[0].total;
                const buyW = (lb.buys / max) * 100;
                const sellW = (lb.sells / max) * 100;
                return (
                  <div className="lb-row" key={lb.name} onClick={() => setF("insider", lb.name.split(",")[0])}>
                    <span className="lb-rank">{(i + 1).toString().padStart(2, "0")}</span>
                    <span className="lb-name">
                      {lb.name}
                      <span className="sub">{lb.tickerCount} {lb.tickerCount === 1 ? "ticker" : "tickers"}</span>
                    </span>
                    <span className="lb-bar">
                      <span className="seg-buy" style={{ width: buyW + "%" }} />
                      <span className="seg-sell" style={{ width: sellW + "%", left: buyW + "%", right: "auto" }} />
                    </span>
                    <span className="lb-count">{lb.total}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Filter bar */}
      <div className="filter-bar">
        <Field label="Date from"><input type="date" className="field-input mono" style={{ width: 138 }} value={filters.dateFrom} onChange={(e) => setF("dateFrom", e.target.value)} /></Field>
        <Field label="Date to"><input type="date" className="field-input mono" style={{ width: 138 }} value={filters.dateTo} onChange={(e) => setF("dateTo", e.target.value)} /></Field>
        <Field label="Ticker"><input className="field-input mono" style={{ width: 100 }} placeholder="e.g. ENB.TO" value={filters.ticker} onChange={(e) => setF("ticker", e.target.value.toUpperCase())} /></Field>
        <Field label="Insider"><input className="field-input" style={{ width: 180 }} placeholder="Search name…" value={filters.insider} onChange={(e) => setF("insider", e.target.value)} /></Field>
        <Field label="Transaction Type">
          <Select value={filters.natureId} onChange={(v) => setF("natureId", v)} options={natureOptions} placeholder="All transaction types" width={300} showCode />
        </Field>
        <div className="divider" />
        <Field label="Min. insiders / ticker">
          <input className="field-input mono" style={{ width: 78 }} type="number" min={1} placeholder="1" value={filters.minInsiders} onChange={(e) => setF("minInsiders", e.target.value)} />
        </Field>
        <div style={{ flex: 1 }} />
        <button className="btn btn-ghost" onClick={clearFilters}>Clear</button>
        <button className="btn btn-primary">Apply Filters</button>
      </div>

      {/* Table */}
      <div className="table-wrap">
        <div className="table-toolbar">
          <span>Showing <b style={{ color: "var(--fg)" }}>{total.toLocaleString()}</b> filings</span>
          {activeFilters.length > 0 && (
            <>
              <span style={{ color: "var(--fg-faint)" }}>·</span>
              {activeFilters.map(([k, v]) => {
                let label = "";
                if (k === "dateFrom") label = "≥ " + v;
                else if (k === "dateTo") label = "≤ " + v;
                else if (k === "ticker") label = "Ticker: " + v;
                else if (k === "insider") label = "Insider: " + v;
                else if (k === "natureId") { const n = MOCK_DATA.NATURE_OF_TXN.find((x) => x.code === v); label = n ? n.code + " - " + n.description.slice(0, 30) : v; }
                else if (k === "minInsiders") label = "≥ " + v + " insiders";
                return (
                  <span className="chip" key={k}>
                    {label}
                    <span className="x" onClick={() => setF(k, k === "natureId" ? null : "")}>×</span>
                  </span>
                );
              })}
            </>
          )}
          <span className="spacer" />
          <span>Sort: <b style={{ color: "var(--fg)" }}>{sort.key.replace(/_/g, " ")}</b> {sort.dir === "asc" ? "↑" : "↓"}</span>
        </div>
        <DataTable
          columns={columns}
          rows={paged}
          sort={sort}
          onSort={handleSort}
          page={page}
          pageSize={pageSize}
          total={total}
          onPage={setPage}
          onPageSize={(n) => { setPageSize(n); setPage(1); }}
        />
      </div>
    </div>
  );
}

// ---------- Heatmap (treemap-ish, single row) ----------
function Heatmap({ items, onSelect }) {
  if (!items.length) return <div className="empty-state">No data.</div>;
  const totalCount = items.reduce((a, b) => a + b.count, 0);
  const maxAbsNet = Math.max(...items.map((i) => Math.abs(i.net))) || 1;

  // simple slice-and-dice into 2 rows
  const rows = [items.slice(0, 6), items.slice(6, 12)];

  return (
    <div className="heatmap-grid">
      {rows.map((row, ri) => {
        const rowSum = row.reduce((a, b) => a + b.count, 0) || 1;
        return (
          <div
            key={ri}
            className="heatmap-row"
            style={{ gridTemplateColumns: row.map((i) => `${i.count / rowSum}fr`).join(" ") }}
          >
            {row.map((it) => {
              const intensity = Math.min(1, Math.abs(it.net) / maxAbsNet);
              const isBuy = it.net >= 0;
              const bg = isBuy
                ? `oklch(${65 - intensity * 12}% ${0.05 + intensity * 0.13} 148)`
                : `oklch(${65 - intensity * 12}% ${0.05 + intensity * 0.16} 28)`;
              const fg = intensity > 0.4 ? "#fff" : "var(--fg)";
              return (
                <div
                  key={it.ticker}
                  className="heat-cell"
                  style={{ background: bg, color: fg }}
                  onClick={() => onSelect(it.ticker)}
                  title={`${it.ticker} · ${it.count} filings · ${it.net >= 0 ? "+" : ""}${fmt.moneyBig(it.net)}`}
                >
                  <span className="ht-sector" style={{ color: intensity > 0.4 ? "rgba(255,255,255,0.7)" : "var(--fg-muted)" }}>{it.sector}</span>
                  <span className="ht-ticker">{it.ticker}</span>
                  <span className="ht-meta">
                    <span>{it.count} flg</span>
                    <span>{it.net >= 0 ? "+" : "−"}{fmt.moneyBig(Math.abs(it.net))}</span>
                  </span>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { Dashboard });
